/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */

#include "ey-ideal-wifi-manager.h"
#include "ey-wifi-phy.h"
#include "ns3/assert.h"
#include "ns3/double.h"
#include <cmath>

namespace ns3 {

struct EyIdealWifiRemoteStation : public EyWifiRemoteStation
{
  double m_lastSnr;
};

NS_OBJECT_ENSURE_REGISTERED (EyIdealWifiManager);

TypeId
EyIdealWifiManager::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyIdealWifiManager")
    .SetParent<EyWifiRemoteStationManager> ()
    .AddConstructor<EyIdealWifiManager> ()
    .AddAttribute ("BerThreshold",
                   "The maximum Bit Error Rate acceptable at any transmission mode",
                   DoubleValue (10e-6),
                   MakeDoubleAccessor (&EyIdealWifiManager::m_ber),
                   MakeDoubleChecker<double> ())
  ;
  return tid;
}

EyIdealWifiManager::EyIdealWifiManager ()
{
}
EyIdealWifiManager::~EyIdealWifiManager ()
{
}

void
EyIdealWifiManager::SetupPhy (Ptr<EyWifiPhy> phy)
{
  uint32_t nModes = phy->GetNModes ();
  for (uint32_t i = 0; i < nModes; i++)
    {
      EyWifiMode mode = phy->GetMode (i);
      AddModeSnrThreshold (mode, phy->CalculateSnr (mode, m_ber));
    }

  EyWifiRemoteStationManager::SetupPhy (phy);
}

double
EyIdealWifiManager::GetSnrThreshold (EyWifiMode mode) const
{
  for (Thresholds::const_iterator i = m_thresholds.begin (); i != m_thresholds.end (); i++)
    {
      if (mode == i->second)
        {
          return i->first;
        }
    }
  NS_ASSERT (false);
  return 0.0;
}

void
EyIdealWifiManager::AddModeSnrThreshold (EyWifiMode mode, double snr)
{
  m_thresholds.push_back (std::make_pair (snr,mode));
}

EyWifiRemoteStation *
EyIdealWifiManager::DoCreateStation (void) const
{
  EyIdealWifiRemoteStation *station = new EyIdealWifiRemoteStation ();
  station->m_lastSnr = 0.0;
  return station;
}


void
EyIdealWifiManager::DoReportRxOk (EyWifiRemoteStation *station,
                                double rxSnr, EyWifiMode txMode)
{
}
void
EyIdealWifiManager::DoReportRtsFailed (EyWifiRemoteStation *station)
{
}
void
EyIdealWifiManager::DoReportDataFailed (EyWifiRemoteStation *station)
{
}
void
EyIdealWifiManager::DoReportRtsOk (EyWifiRemoteStation *st,
                                 double ctsSnr, EyWifiMode ctsMode, double rtsSnr)
{
  EyIdealWifiRemoteStation *station = (EyIdealWifiRemoteStation *)st;
  station->m_lastSnr = rtsSnr;
}
void
EyIdealWifiManager::DoReportDataOk (EyWifiRemoteStation *st,
                                  double ackSnr, EyWifiMode ackMode, double dataSnr)
{
  EyIdealWifiRemoteStation *station = (EyIdealWifiRemoteStation *)st;
  station->m_lastSnr = dataSnr;
}
void
EyIdealWifiManager::DoReportFinalRtsFailed (EyWifiRemoteStation *station)
{
}
void
EyIdealWifiManager::DoReportFinalDataFailed (EyWifiRemoteStation *station)
{
}

EyWifiMode
EyIdealWifiManager::DoGetDataMode (EyWifiRemoteStation *st, uint32_t size)
{
  EyIdealWifiRemoteStation *station = (EyIdealWifiRemoteStation *)st;
  // We search within the Supported rate set the mode with the
  // highest snr threshold possible which is smaller than m_lastSnr
  // to ensure correct packet delivery.
  double maxThreshold = 0.0;
  EyWifiMode maxMode = GetDefaultMode ();
  for (uint32_t i = 0; i < GetNSupported (station); i++)
    {
      EyWifiMode mode = GetSupported (station, i);
      double threshold = GetSnrThreshold (mode);
      if (threshold > maxThreshold
          && threshold < station->m_lastSnr)
        {
          maxThreshold = threshold;
          maxMode = mode;
        }
    }
  return maxMode;
}
EyWifiMode
EyIdealWifiManager::DoGetRtsMode (EyWifiRemoteStation *st)
{
  EyIdealWifiRemoteStation *station = (EyIdealWifiRemoteStation *)st;
  // We search within the Basic rate set the mode with the highest
  // snr threshold possible which is smaller than m_lastSnr to
  // ensure correct packet delivery.
  double maxThreshold = 0.0;
  EyWifiMode maxMode = GetDefaultMode ();
  for (uint32_t i = 0; i < GetNBasicModes (); i++)
    {
      EyWifiMode mode = GetBasicMode (i);
      double threshold = GetSnrThreshold (mode);
      if (threshold > maxThreshold
          && threshold < station->m_lastSnr)
        {
          maxThreshold = threshold;
          maxMode = mode;
        }
    }
  return maxMode;
}

bool
EyIdealWifiManager::IsLowLatency (void) const
{
  return true;
}

} // namespace ns3
