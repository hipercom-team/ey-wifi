/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <hana.baccouch@inria.fr>
 */

#include "ns3/assert.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include <math.h>
#include "ey-ey-manager.h"
#include "ey-wifi-phy.h"
#include "ey-wifi-mac.h"
#include "ey-mac-low.h"
#include "ey-dca-txop.h"
NS_LOG_COMPONENT_DEFINE ("EyState");

#define MY_DEBUG(x) \
  NS_LOG_DEBUG (Simulator::Now () << " " << this << " " << x)

namespace ns3 {
  
/****************************************************************
 *      Implement the DCF state holder
 ****************************************************************/

 EyState::EyState (EyDcaTxop *txop)
   : m_txop (txop),
     m_burstSlots (1)
{
  SetAifsn(0);
}

EyState::~EyState ()
{
}

void
EyState:: DoNotifyAccessGranted (void) 
{
  //m_txop->NotifyBurstAccessGranted();
  m_txop->NotifyAccessGranted();
}

void
EyState:: DoNotifyInternalCollision (void)
{
  m_txop->NotifyInternalCollision ();
}

void 
EyState::DoNotifyCollision (void)
{
  m_txop->NotifyCollision ();
}

void 
EyState::DoNotifyChannelSwitching () 
{
  m_txop->NotifyChannelSwitching ();
}
} // namespace ns3
