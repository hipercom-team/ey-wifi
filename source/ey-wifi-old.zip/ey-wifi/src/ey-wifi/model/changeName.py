import re,os

rInclude = re.compile('[#]include.+["](.+)["]')

def readFile(fileName):
    f = open(fileName)
    result = f.read()
    f.close()
    return result

def writeFile(fileName, data):
    f = open(fileName, "w")
    f.write(data)
    f.close()

def fixInclude(fileName, origFileList):
    data = readFile(fileName)
    lineList = data.split("\n")
    newLineList = []
    for line in lineList:
        if line.find("#include") >= 0:
            m = rInclude.search(line)
            if m != None:
                incName = m.group(1)
                assert not (incName.find("/") >= 0 and not incName.startswith("ns3/"))
                if incName.startswith("ns3/"):
                    incTrueName = incName[4:]
                    if incTrueName in origFileList:
                        line = line.replace(incTrueName, "ey-"+incTrueName)
                else:
                    if incName in origFileList:
                        line = line.replace(incName, "ey-"+incName)
        newLineList.append(line)
    newData = "\n".join(newLineList)
    writeFile(fileName, newData)


fileList = os.listdir(".")

cxxFileList = [ x for x in fileList
                if (x.endswith(".cc") or x.endswith(".h") ) ]
                

eyFileList = [ x for x in cxxFileList
               if x.startswith("ey-") ]

origFileList = [x[3:] for x in eyFileList]

for fileName in cxxFileList:
    fixInclude(fileName, origFileList)
