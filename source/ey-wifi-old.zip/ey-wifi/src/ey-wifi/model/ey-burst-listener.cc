/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <haha.baccouch@inria.fr>
 */
#include "ey-burst-listener.h"
//#include "ey-dca-txop.h"
#include "ey-wifi-phy.h"
#include "ey-yans-wifi-phy.h"
#include "ns3/nstime.h"
#include "ns3/event-id.h"
#include "ns3/log.h"

NS_LOG_COMPONENT_DEFINE ("BurstListener");

#define MY_DEBUG(x) \
  NS_LOG_DEBUG (Simulator::Now () << " " << this << " " << x)
  
namespace ns3 {

  BurstListener::BurstListener (Ptr<EyWifiPhy> wifiPhy)
  {
    m_wifiPhy=wifiPhy;
  }

  BurstListener::~BurstListener () {}

  void 
  BurstListener::DoNotifyBurstTxBegin(uint32_t slots) 
  {
    m_wifiPhy->NotifyBurstTxBegin(slots);
  }
  void 
  BurstListener::DoNotifyBurstTxEnd (uint32_t slots)
  {
    m_wifiPhy->NotifyBurstTxEnd(slots);
  }
  void
  BurstListener::DoNotifyBurstTxDrop (uint32_t slots)
  {
    //m_wifiPhy->NotifyBurstTxDrop(slots);
  }
  void
  BurstListener::DoNotifyYieldBegin (uint32_t slots)
  {
    //m_wifiPhy->NotifyYieldBegin(slots);
  }
  void
  BurstListener::DoNotifyYieldDrop (uint32_t slots)
  {
     //m_wifiPhy->NotifyYieldDrop(slots);
  }
}
