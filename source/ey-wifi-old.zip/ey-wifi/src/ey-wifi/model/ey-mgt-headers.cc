/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2006 INRIA
 * Copyright (c) 2009 MIRKO BANCHI
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 * Author: Mirko Banchi <mk.banchi@gmail.com>
 */
#include "ey-mgt-headers.h"
#include "ns3/simulator.h"
#include "ns3/assert.h"

namespace ns3 {

/***********************************************************
 *          Probe Request
 ***********************************************************/

NS_OBJECT_ENSURE_REGISTERED (EyMgtProbeRequestHeader);

EyMgtProbeRequestHeader::~EyMgtProbeRequestHeader ()
{
}

void
EyMgtProbeRequestHeader::SetSsid (EySsid ssid)
{
  m_ssid = ssid;
}
EySsid
EyMgtProbeRequestHeader::GetSsid (void) const
{
  return m_ssid;
}
void
EyMgtProbeRequestHeader::SetSupportedRates (EySupportedRates rates)
{
  m_rates = rates;
}

EySupportedRates
EyMgtProbeRequestHeader::GetSupportedRates (void) const
{
  return m_rates;
}
uint32_t
EyMgtProbeRequestHeader::GetSerializedSize (void) const
{
  uint32_t size = 0;
  size += m_ssid.GetSerializedSize ();
  size += m_rates.GetSerializedSize ();
  size += m_rates.extended.GetSerializedSize ();
  return size;
}
TypeId
EyMgtProbeRequestHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyMgtProbeRequestHeader")
    .SetParent<Header> ()
    .AddConstructor<EyMgtProbeRequestHeader> ()
  ;
  return tid;
}
TypeId
EyMgtProbeRequestHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
void
EyMgtProbeRequestHeader::Print (std::ostream &os) const
{
  os << "ssid=" << m_ssid << ", "
     << "rates=" << m_rates;
}
void
EyMgtProbeRequestHeader::Serialize (Buffer::Iterator start) const
{
  Buffer::Iterator i = start;
  i = m_ssid.Serialize (i);
  i = m_rates.Serialize (i);
  i = m_rates.extended.Serialize (i);
}
uint32_t
EyMgtProbeRequestHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  i = m_ssid.Deserialize (i);
  i = m_rates.Deserialize (i);
  i = m_rates.extended.DeserializeIfPresent (i);
  return i.GetDistanceFrom (start);
}


/***********************************************************
 *          Probe Response
 ***********************************************************/

NS_OBJECT_ENSURE_REGISTERED (EyMgtProbeResponseHeader);

EyMgtProbeResponseHeader::EyMgtProbeResponseHeader ()
{
}
EyMgtProbeResponseHeader::~EyMgtProbeResponseHeader ()
{
}
uint64_t
EyMgtProbeResponseHeader::GetTimestamp ()
{
  return m_timestamp;
}
EySsid
EyMgtProbeResponseHeader::GetSsid (void) const
{
  return m_ssid;
}
uint64_t
EyMgtProbeResponseHeader::GetBeaconIntervalUs (void) const
{
  return m_beaconInterval;
}
EySupportedRates
EyMgtProbeResponseHeader::GetSupportedRates (void) const
{
  return m_rates;
}

void
EyMgtProbeResponseHeader::SetSsid (EySsid ssid)
{
  m_ssid = ssid;
}
void
EyMgtProbeResponseHeader::SetBeaconIntervalUs (uint64_t us)
{
  m_beaconInterval = us;
}
void
EyMgtProbeResponseHeader::SetSupportedRates (EySupportedRates rates)
{
  m_rates = rates;
}
TypeId
EyMgtProbeResponseHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyMgtProbeResponseHeader")
    .SetParent<Header> ()
    .AddConstructor<EyMgtProbeResponseHeader> ()
  ;
  return tid;
}
TypeId
EyMgtProbeResponseHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
EyMgtProbeResponseHeader::GetSerializedSize (void) const
{
  uint32_t size = 0;
  size += 8; // timestamp
  size += 2; // beacon interval
  size += m_capability.GetSerializedSize ();
  size += m_ssid.GetSerializedSize ();
  size += m_rates.GetSerializedSize ();
  //size += 3; // ds parameter set
  size += m_rates.extended.GetSerializedSize ();
  // xxx
  return size;
}
void
EyMgtProbeResponseHeader::Print (std::ostream &os) const
{
  os << "ssid=" << m_ssid << ", "
     << "rates=" << m_rates;
}
void
EyMgtProbeResponseHeader::Serialize (Buffer::Iterator start) const
{
  // timestamp
  // beacon interval
  // capability information
  // ssid
  // supported rates
  // fh parameter set
  // ds parameter set
  // cf parameter set
  // ibss parameter set
  //XXX
  Buffer::Iterator i = start;
  i.WriteHtolsbU64 (Simulator::Now ().GetMicroSeconds ());
  i.WriteHtolsbU16 (m_beaconInterval / 1024);
  i = m_capability.Serialize (i);
  i = m_ssid.Serialize (i);
  i = m_rates.Serialize (i);
  //i.WriteU8 (0, 3); // ds parameter set.
  i = m_rates.extended.Serialize (i);
}
uint32_t
EyMgtProbeResponseHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  m_timestamp = i.ReadLsbtohU64 ();
  m_beaconInterval = i.ReadLsbtohU16 ();
  m_beaconInterval *= 1024;
  i = m_capability.Deserialize (i);
  i = m_ssid.Deserialize (i);
  i = m_rates.Deserialize (i);
  //i.Next (3); // ds parameter set
  i = m_rates.extended.DeserializeIfPresent (i);
  return i.GetDistanceFrom (start);
}

/***********************************************************
 *          Assoc Request
 ***********************************************************/

NS_OBJECT_ENSURE_REGISTERED (EyMgtAssocRequestHeader);

EyMgtAssocRequestHeader::EyMgtAssocRequestHeader ()
  : m_listenInterval (0)
{
}
EyMgtAssocRequestHeader::~EyMgtAssocRequestHeader ()
{
}

void
EyMgtAssocRequestHeader::SetSsid (EySsid ssid)
{
  m_ssid = ssid;
}
void
EyMgtAssocRequestHeader::SetSupportedRates (EySupportedRates rates)
{
  m_rates = rates;
}
void
EyMgtAssocRequestHeader::SetListenInterval (uint16_t interval)
{
  m_listenInterval = interval;
}
EySsid
EyMgtAssocRequestHeader::GetSsid (void) const
{
  return m_ssid;
}
EySupportedRates
EyMgtAssocRequestHeader::GetSupportedRates (void) const
{
  return m_rates;
}
uint16_t
EyMgtAssocRequestHeader::GetListenInterval (void) const
{
  return m_listenInterval;
}

TypeId
EyMgtAssocRequestHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyMgtAssocRequestHeader")
    .SetParent<Header> ()
    .AddConstructor<EyMgtAssocRequestHeader> ()
  ;
  return tid;
}
TypeId
EyMgtAssocRequestHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
EyMgtAssocRequestHeader::GetSerializedSize (void) const
{
  uint32_t size = 0;
  size += m_capability.GetSerializedSize ();
  size += 2;
  size += m_ssid.GetSerializedSize ();
  size += m_rates.GetSerializedSize ();
  size += m_rates.extended.GetSerializedSize ();
  return size;
}
void
EyMgtAssocRequestHeader::Print (std::ostream &os) const
{
  os << "ssid=" << m_ssid << ", "
     << "rates=" << m_rates;
}
void
EyMgtAssocRequestHeader::Serialize (Buffer::Iterator start) const
{
  Buffer::Iterator i = start;
  i = m_capability.Serialize (i);
  i.WriteHtolsbU16 (m_listenInterval);
  i = m_ssid.Serialize (i);
  i = m_rates.Serialize (i);
  i = m_rates.extended.Serialize (i);
}
uint32_t
EyMgtAssocRequestHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  i = m_capability.Deserialize (i);
  m_listenInterval = i.ReadLsbtohU16 ();
  i = m_ssid.Deserialize (i);
  i = m_rates.Deserialize (i);
  i = m_rates.extended.DeserializeIfPresent (i);
  return i.GetDistanceFrom (start);
}

/***********************************************************
 *          Assoc Response
 ***********************************************************/

NS_OBJECT_ENSURE_REGISTERED (EyMgtAssocResponseHeader);

EyMgtAssocResponseHeader::EyMgtAssocResponseHeader ()
  : m_aid (0)
{
}
EyMgtAssocResponseHeader::~EyMgtAssocResponseHeader ()
{
}

EyStatusCode
EyMgtAssocResponseHeader::GetStatusCode (void)
{
  return m_code;
}
EySupportedRates
EyMgtAssocResponseHeader::GetSupportedRates (void)
{
  return m_rates;
}
void
EyMgtAssocResponseHeader::SetStatusCode (EyStatusCode code)
{
  m_code = code;
}
void
EyMgtAssocResponseHeader::SetSupportedRates (EySupportedRates rates)
{
  m_rates = rates;
}

TypeId
EyMgtAssocResponseHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyMgtAssocResponseHeader")
    .SetParent<Header> ()
    .AddConstructor<EyMgtAssocResponseHeader> ()
  ;
  return tid;
}
TypeId
EyMgtAssocResponseHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
EyMgtAssocResponseHeader::GetSerializedSize (void) const
{
  uint32_t size = 0;
  size += m_capability.GetSerializedSize ();
  size += m_code.GetSerializedSize ();
  size += 2; // aid
  size += m_rates.GetSerializedSize ();
  size += m_rates.extended.GetSerializedSize ();
  return size;
}

void
EyMgtAssocResponseHeader::Print (std::ostream &os) const
{
  os << "status code=" << m_code << ", "
     << "rates=" << m_rates;
}
void
EyMgtAssocResponseHeader::Serialize (Buffer::Iterator start) const
{
  Buffer::Iterator i = start;
  i = m_capability.Serialize (i);
  i = m_code.Serialize (i);
  i.WriteHtolsbU16 (m_aid);
  i = m_rates.Serialize (i);
  i = m_rates.extended.Serialize (i);
}
uint32_t
EyMgtAssocResponseHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  i = m_capability.Deserialize (i);
  i = m_code.Deserialize (i);
  m_aid = i.ReadLsbtohU16 ();
  i = m_rates.Deserialize (i);
  i = m_rates.extended.DeserializeIfPresent (i);
  return i.GetDistanceFrom (start);
}
/**********************************************************
 *   ActionFrame
 **********************************************************/
EyWifiActionHeader::EyWifiActionHeader ()
{
}
EyWifiActionHeader::~EyWifiActionHeader ()
{
}
void
EyWifiActionHeader::SetAction (EyWifiActionHeader::CategoryValue type,
                             EyWifiActionHeader::ActionValue action)
{
  m_category = type;

  switch (type)
    {
    case BLOCK_ACK:
      {
        m_actionValue = action.blockAck;
        break;
      }
    case MESH_PEERING_MGT:
      {
        m_actionValue = action.peerLink;
        break;
      }
    case MESH_PATH_SELECTION:
      {
        m_actionValue = action.pathSelection;
        break;
      }
    case MESH_LINK_METRIC:
    case MESH_INTERWORKING:
    case MESH_RESOURCE_COORDINATION:
    case MESH_PROXY_FORWARDING:
      break;
    }
}
EyWifiActionHeader::CategoryValue
EyWifiActionHeader::GetCategory ()
{
  switch (m_category)
    {
    case BLOCK_ACK:
      return BLOCK_ACK;
    case MESH_PEERING_MGT:
      return MESH_PEERING_MGT;
    case MESH_LINK_METRIC:
      return MESH_LINK_METRIC;
    case MESH_PATH_SELECTION:
      return MESH_PATH_SELECTION;
    case MESH_INTERWORKING:
      return MESH_INTERWORKING;
    case MESH_RESOURCE_COORDINATION:
      return MESH_RESOURCE_COORDINATION;
    case MESH_PROXY_FORWARDING:
      return MESH_PROXY_FORWARDING;
    default:
      NS_FATAL_ERROR ("Unknown action value");
      return MESH_PEERING_MGT;
    }
}
EyWifiActionHeader::ActionValue
EyWifiActionHeader::GetAction ()
{
  ActionValue retval;
  retval.peerLink = PEER_LINK_OPEN; // Needs to be initialized to something to quiet valgrind in default cases
  switch (m_category)
    {
    case BLOCK_ACK:
      switch (m_actionValue)
        {
        case BLOCK_ACK_ADDBA_REQUEST:
          retval.blockAck = BLOCK_ACK_ADDBA_REQUEST;
          return retval;
        case BLOCK_ACK_ADDBA_RESPONSE:
          retval.blockAck = BLOCK_ACK_ADDBA_RESPONSE;
          return retval;
        case BLOCK_ACK_DELBA:
          retval.blockAck = BLOCK_ACK_DELBA;
          return retval;
        }
    case MESH_PEERING_MGT:
      switch (m_actionValue)
        {
        case PEER_LINK_OPEN:
          retval.peerLink = PEER_LINK_OPEN;
          return retval;
        case PEER_LINK_CONFIRM:
          retval.peerLink = PEER_LINK_CONFIRM;
          return retval;
        case PEER_LINK_CLOSE:
          retval.peerLink = PEER_LINK_CLOSE;
          return retval;
        default:
          NS_FATAL_ERROR ("Unknown mesh peering management action code");
          retval.peerLink = PEER_LINK_OPEN; /* quiet compiler */
          return retval;
        }
    case MESH_PATH_SELECTION:
      switch (m_actionValue)
        {
        case PATH_SELECTION:
          retval.pathSelection = PATH_SELECTION;
          return retval;
        default:
          NS_FATAL_ERROR ("Unknown mesh path selection action code");
          retval.peerLink = PEER_LINK_OPEN; /* quiet compiler */
          return retval;
        }
    case MESH_LINK_METRIC:
    // not yet supported
    case MESH_INTERWORKING:
    // not yet supported
    case MESH_RESOURCE_COORDINATION:
    // not yet supported
    default:
      NS_FATAL_ERROR ("Unsupported mesh action");
      retval.peerLink = PEER_LINK_OPEN; /* quiet compiler */
      return retval;
    }
}
TypeId
EyWifiActionHeader::GetTypeId ()
{
  static TypeId tid = TypeId ("ns3::EyWifiActionHeader")
    .SetParent<Header> ()
    .AddConstructor<EyWifiActionHeader> ();
  return tid;
}
TypeId
EyWifiActionHeader::GetInstanceTypeId () const
{
  return GetTypeId ();
}
void
EyWifiActionHeader::Print (std::ostream &os) const
{
}
uint32_t
EyWifiActionHeader::GetSerializedSize () const
{
  return 2;
}
void
EyWifiActionHeader::Serialize (Buffer::Iterator start) const
{
  start.WriteU8 (m_category);
  start.WriteU8 (m_actionValue);
}
uint32_t
EyWifiActionHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  m_category = i.ReadU8 ();
  m_actionValue = i.ReadU8 ();
  return i.GetDistanceFrom (start);
}

/***************************************************
*                 ADDBARequest
****************************************************/

NS_OBJECT_ENSURE_REGISTERED (EyMgtAddBaRequestHeader);

EyMgtAddBaRequestHeader::EyMgtAddBaRequestHeader ()
  : m_dialogToken (1),
    m_amsduSupport (1),
    m_bufferSize (0)
{
}

TypeId
EyMgtAddBaRequestHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyMgtAddBaRequestHeader")
    .SetParent<Header> ()
    .AddConstructor<EyMgtAddBaRequestHeader> ();
  return tid;
}

TypeId
EyMgtAddBaRequestHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
EyMgtAddBaRequestHeader::Print (std::ostream &os) const
{
}

uint32_t
EyMgtAddBaRequestHeader::GetSerializedSize (void) const
{
  uint32_t size = 0;
  size += 1; //Dialog token
  size += 2; //Block ack parameter set
  size += 2; //Block ack timeout value
  size += 2; //Starting sequence control
  return size;
}

void
EyMgtAddBaRequestHeader::Serialize (Buffer::Iterator start) const
{
  Buffer::Iterator i = start;
  i.WriteU8 (m_dialogToken);
  i.WriteHtolsbU16 (GetParameterSet ());
  i.WriteHtolsbU16 (m_timeoutValue);
  i.WriteHtolsbU16 (GetStartingSequenceControl ());
}

uint32_t
EyMgtAddBaRequestHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  m_dialogToken = i.ReadU8 ();
  SetParameterSet (i.ReadLsbtohU16 ());
  m_timeoutValue = i.ReadLsbtohU16 ();
  SetStartingSequenceControl (i.ReadLsbtohU16 ());
  return i.GetDistanceFrom (start);
}

void
EyMgtAddBaRequestHeader::SetDelayedBlockAck ()
{
  m_policy = 0;
}

void
EyMgtAddBaRequestHeader::SetImmediateBlockAck ()
{
  m_policy = 1;
}

void
EyMgtAddBaRequestHeader::SetTid (uint8_t tid)
{
  NS_ASSERT (tid < 16);
  m_tid = tid;
}

void
EyMgtAddBaRequestHeader::SetTimeout (uint16_t timeout)
{
  m_timeoutValue = timeout;
}

void
EyMgtAddBaRequestHeader::SetBufferSize (uint16_t size)
{
  m_bufferSize = size;
}

void
EyMgtAddBaRequestHeader::SetStartingSequence (uint16_t seq)
{
  m_startingSeq = seq;
}

void
EyMgtAddBaRequestHeader::SetAmsduSupport (bool supported)
{
  m_amsduSupport = supported;
}

uint8_t
EyMgtAddBaRequestHeader::GetTid (void) const
{
  return m_tid;
}

bool
EyMgtAddBaRequestHeader::IsImmediateBlockAck (void) const
{
  return (m_policy == 1) ? true : false;
}

uint16_t
EyMgtAddBaRequestHeader::GetTimeout (void) const
{
  return m_timeoutValue;
}

uint16_t
EyMgtAddBaRequestHeader::GetBufferSize (void) const
{
  return m_bufferSize;
}

bool
EyMgtAddBaRequestHeader::IsAmsduSupported (void) const
{
  return (m_amsduSupport == 1) ? true : false;
}

uint16_t
EyMgtAddBaRequestHeader::GetStartingSequence (void) const
{
  return m_startingSeq;
}

uint16_t
EyMgtAddBaRequestHeader::GetStartingSequenceControl (void) const
{
  return (m_startingSeq << 4) & 0xfff0;
}

void
EyMgtAddBaRequestHeader::SetStartingSequenceControl (uint16_t seqControl)
{
  m_startingSeq = (seqControl >> 4) & 0x0fff;
}

uint16_t
EyMgtAddBaRequestHeader::GetParameterSet (void) const
{
  uint16_t res = 0;
  res |= m_amsduSupport;
  res |= m_policy << 1;
  res |= m_tid << 2;
  res |= m_bufferSize << 6;
  return res;
}

void
EyMgtAddBaRequestHeader::SetParameterSet (uint16_t params)
{
  m_amsduSupport = (params) & 0x01;
  m_policy = (params >> 1) & 0x01;
  m_tid = (params >> 2) & 0x0f;
  m_bufferSize = (params >> 6) & 0x03ff;
}

/***************************************************
*                 ADDBAResponse
****************************************************/

NS_OBJECT_ENSURE_REGISTERED (EyMgtAddBaResponseHeader);

EyMgtAddBaResponseHeader::EyMgtAddBaResponseHeader ()
  : m_dialogToken (1),
    m_amsduSupport (1),
    m_bufferSize (0)
{
}

TypeId
EyMgtAddBaResponseHeader::GetTypeId ()
{
  static TypeId tid = TypeId ("ns3::EyMgtAddBaResponseHeader")
    .SetParent<Header> ()
    .AddConstructor<EyMgtAddBaResponseHeader> ()
  ;
  return tid;
}

TypeId
EyMgtAddBaResponseHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
EyMgtAddBaResponseHeader::Print (std::ostream &os) const
{
  os << "status code=" << m_code;
}

uint32_t
EyMgtAddBaResponseHeader::GetSerializedSize (void) const
{
  uint32_t size = 0;
  size += 1; //Dialog token
  size += m_code.GetSerializedSize (); //Status code
  size += 2; //Block ack parameter set
  size += 2; //Block ack timeout value
  return size;
}

void
EyMgtAddBaResponseHeader::Serialize (Buffer::Iterator start) const
{
  Buffer::Iterator i = start;
  i.WriteU8 (m_dialogToken);
  i = m_code.Serialize (i);
  i.WriteHtolsbU16 (GetParameterSet ());
  i.WriteHtolsbU16 (m_timeoutValue);
}

uint32_t
EyMgtAddBaResponseHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  m_dialogToken = i.ReadU8 ();
  i = m_code.Deserialize (i);
  SetParameterSet (i.ReadLsbtohU16 ());
  m_timeoutValue = i.ReadLsbtohU16 ();
  return i.GetDistanceFrom (start);
}

void
EyMgtAddBaResponseHeader::SetDelayedBlockAck ()
{
  m_policy = 0;
}

void
EyMgtAddBaResponseHeader::SetImmediateBlockAck ()
{
  m_policy = 1;
}

void
EyMgtAddBaResponseHeader::SetTid (uint8_t tid)
{
  NS_ASSERT (tid < 16);
  m_tid = tid;
}

void
EyMgtAddBaResponseHeader::SetTimeout (uint16_t timeout)
{
  m_timeoutValue = timeout;
}

void
EyMgtAddBaResponseHeader::SetBufferSize (uint16_t size)
{
  m_bufferSize = size;
}

void
EyMgtAddBaResponseHeader::SetStatusCode (EyStatusCode code)
{
  m_code = code;
}

void
EyMgtAddBaResponseHeader::SetAmsduSupport (bool supported)
{
  m_amsduSupport = supported;
}

EyStatusCode
EyMgtAddBaResponseHeader::GetStatusCode (void) const
{
  return m_code;
}

uint8_t
EyMgtAddBaResponseHeader::GetTid (void) const
{
  return m_tid;
}

bool
EyMgtAddBaResponseHeader::IsImmediateBlockAck (void) const
{
  return (m_policy == 1) ? true : false;
}

uint16_t
EyMgtAddBaResponseHeader::GetTimeout (void) const
{
  return m_timeoutValue;
}

uint16_t
EyMgtAddBaResponseHeader::GetBufferSize (void) const
{
  return m_bufferSize;
}

bool
EyMgtAddBaResponseHeader::IsAmsduSupported (void) const
{
  return (m_amsduSupport == 1) ? true : false;
}

uint16_t
EyMgtAddBaResponseHeader::GetParameterSet (void) const
{
  uint16_t res = 0;
  res |= m_amsduSupport;
  res |= m_policy << 1;
  res |= m_tid << 2;
  res |= m_bufferSize << 6;
  return res;
}

void
EyMgtAddBaResponseHeader::SetParameterSet (uint16_t params)
{
  m_amsduSupport = (params) & 0x01;
  m_policy = (params >> 1) & 0x01;
  m_tid = (params >> 2) & 0x0f;
  m_bufferSize = (params >> 6) & 0x03ff;
}

/***************************************************
*                     DelBa
****************************************************/

NS_OBJECT_ENSURE_REGISTERED (EyMgtDelBaHeader);

EyMgtDelBaHeader::EyMgtDelBaHeader ()
  : m_reasonCode (1)
{
}

TypeId
EyMgtDelBaHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyMgtDelBaHeader")
    .SetParent<Header> ()
    .AddConstructor<EyMgtDelBaHeader> ()
  ;
  return tid;
}

TypeId
EyMgtDelBaHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
EyMgtDelBaHeader::Print (std::ostream &os) const
{
}

uint32_t
EyMgtDelBaHeader::GetSerializedSize (void) const
{
  uint32_t size = 0;
  size += 2; //DelBa parameter set
  size += 2; //Reason code
  return size;
}

void
EyMgtDelBaHeader::Serialize (Buffer::Iterator start) const
{
  Buffer::Iterator i = start;
  i.WriteHtolsbU16 (GetParameterSet ());
  i.WriteHtolsbU16 (m_reasonCode);
}

uint32_t
EyMgtDelBaHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;
  SetParameterSet (i.ReadLsbtohU16 ());
  m_reasonCode = i.ReadLsbtohU16 ();
  return i.GetDistanceFrom (start);
}

bool
EyMgtDelBaHeader::IsByOriginator (void) const
{
  return (m_initiator == 1) ? true : false;
}

uint8_t
EyMgtDelBaHeader::GetTid (void) const
{
  NS_ASSERT (m_tid < 16);
  uint8_t tid = static_cast<uint8_t> (m_tid);
  return tid;
}

void
EyMgtDelBaHeader::SetByOriginator (void)
{
  m_initiator = 1;
}

void
EyMgtDelBaHeader::SetByRecipient (void)
{
  m_initiator = 0;
}

void
EyMgtDelBaHeader::SetTid (uint8_t tid)
{
  NS_ASSERT (tid < 16);
  m_tid = static_cast<uint16_t> (tid);
}

uint16_t
EyMgtDelBaHeader::GetParameterSet (void) const
{
  uint16_t res = 0;
  res |= m_initiator << 11;
  res |= m_tid << 12;
  return res;
}

void
EyMgtDelBaHeader::SetParameterSet (uint16_t params)
{
  m_initiator = (params >> 11) & 0x01;
  m_tid = (params >> 12) & 0x0f;
}

} // namespace ns3
