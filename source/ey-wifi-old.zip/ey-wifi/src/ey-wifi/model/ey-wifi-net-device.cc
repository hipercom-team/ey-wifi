/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */
#include "ey-wifi-net-device.h"
#include "ey-wifi-mac.h"
#include "ey-wifi-phy.h"
#include "ey-wifi-remote-station-manager.h"
#include "ey-wifi-channel.h"
#include "ns3/llc-snap-header.h"
#include "ns3/packet.h"
#include "ns3/uinteger.h"
#include "ns3/pointer.h"
#include "ns3/node.h"
#include "ns3/trace-source-accessor.h"
#include "ns3/log.h"

NS_LOG_COMPONENT_DEFINE ("EyWifiNetDevice");

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (EyWifiNetDevice);

TypeId
EyWifiNetDevice::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyWifiNetDevice")
    .SetParent<NetDevice> ()
    .AddConstructor<EyWifiNetDevice> ()
    .AddAttribute ("Mtu", "The MAC-level Maximum Transmission Unit",
                   UintegerValue (MAX_MSDU_SIZE - LLC_SNAP_HEADER_LENGTH),
                   MakeUintegerAccessor (&EyWifiNetDevice::SetMtu,
                                         &EyWifiNetDevice::GetMtu),
                   MakeUintegerChecker<uint16_t> (1,MAX_MSDU_SIZE - LLC_SNAP_HEADER_LENGTH))
    .AddAttribute ("Channel", "The channel attached to this device",
                   PointerValue (),
                   MakePointerAccessor (&EyWifiNetDevice::DoGetChannel),
                   MakePointerChecker<EyWifiChannel> ())
    .AddAttribute ("Phy", "The PHY layer attached to this device.",
                   PointerValue (),
                   MakePointerAccessor (&EyWifiNetDevice::GetPhy,
                                        &EyWifiNetDevice::SetPhy),
                   MakePointerChecker<EyWifiPhy> ())
    .AddAttribute ("Mac", "The MAC layer attached to this device.",
                   PointerValue (),
                   MakePointerAccessor (&EyWifiNetDevice::GetMac,
                                        &EyWifiNetDevice::SetMac),
                   MakePointerChecker<EyWifiMac> ())
    .AddAttribute ("RemoteStationManager", "The station manager attached to this device.",
                   PointerValue (),
                   MakePointerAccessor (&EyWifiNetDevice::SetRemoteStationManager,
                                        &EyWifiNetDevice::GetRemoteStationManager),
                   MakePointerChecker<EyWifiRemoteStationManager> ())
  ;
  return tid;
}

EyWifiNetDevice::EyWifiNetDevice ()
  : m_configComplete (false)
{
  NS_LOG_FUNCTION_NOARGS ();
}
EyWifiNetDevice::~EyWifiNetDevice ()
{
  NS_LOG_FUNCTION_NOARGS ();
}

void
EyWifiNetDevice::DoDispose (void)
{
  NS_LOG_FUNCTION_NOARGS ();
  m_node = 0;
  m_mac->Dispose ();
  m_phy->Dispose ();
  m_stationManager->Dispose ();
  m_mac = 0;
  m_phy = 0;
  m_stationManager = 0;
  // chain up.
  NetDevice::DoDispose ();
}

void
EyWifiNetDevice::DoStart (void)
{
  m_phy->Start ();
  m_mac->Start ();
  m_stationManager->Start ();
  NetDevice::DoStart ();
}

void
EyWifiNetDevice::CompleteConfig (void)
{
  if (m_mac == 0
      || m_phy == 0
      || m_stationManager == 0
      || m_node == 0
      || m_configComplete)
    {
      return;
    }
  m_mac->SetWifiRemoteStationManager (m_stationManager);
  m_mac->SetWifiPhy (m_phy);
  m_mac->SetForwardUpCallback (MakeCallback (&EyWifiNetDevice::ForwardUp, this));
  m_mac->SetLinkUpCallback (MakeCallback (&EyWifiNetDevice::LinkUp, this));
  m_mac->SetLinkDownCallback (MakeCallback (&EyWifiNetDevice::LinkDown, this));
  m_stationManager->SetupPhy (m_phy);
  m_configComplete = true;
}

void
EyWifiNetDevice::SetMac (Ptr<EyWifiMac> mac)
{
  m_mac = mac;
  CompleteConfig ();
}
void
EyWifiNetDevice::SetPhy (Ptr<EyWifiPhy> phy)
{
  m_phy = phy;
  CompleteConfig ();
}
void
EyWifiNetDevice::SetRemoteStationManager (Ptr<EyWifiRemoteStationManager> manager)
{
  m_stationManager = manager;
  CompleteConfig ();
}
Ptr<EyWifiMac>
EyWifiNetDevice::GetMac (void) const
{
  return m_mac;
}
Ptr<EyWifiPhy>
EyWifiNetDevice::GetPhy (void) const
{
  return m_phy;
}
Ptr<EyWifiRemoteStationManager>
EyWifiNetDevice::GetRemoteStationManager (void) const
{
  return m_stationManager;
}

void
EyWifiNetDevice::SetIfIndex (const uint32_t index)
{
  m_ifIndex = index;
}
uint32_t
EyWifiNetDevice::GetIfIndex (void) const
{
  return m_ifIndex;
}
Ptr<Channel>
EyWifiNetDevice::GetChannel (void) const
{
  return m_phy->GetChannel ();
}
Ptr<EyWifiChannel>
EyWifiNetDevice::DoGetChannel (void) const
{
  return m_phy->GetChannel ();
}
void
EyWifiNetDevice::SetAddress (Address address)
{
  m_mac->SetAddress (Mac48Address::ConvertFrom (address));
}
Address
EyWifiNetDevice::GetAddress (void) const
{
  return m_mac->GetAddress ();
}
bool
EyWifiNetDevice::SetMtu (const uint16_t mtu)
{
  if (mtu > MAX_MSDU_SIZE - LLC_SNAP_HEADER_LENGTH)
    {
      return false;
    }
  m_mtu = mtu;
  return true;
}
uint16_t
EyWifiNetDevice::GetMtu (void) const
{
  return m_mtu;
}
bool
EyWifiNetDevice::IsLinkUp (void) const
{
  return m_phy != 0 && m_linkUp;
}
void
EyWifiNetDevice::AddLinkChangeCallback (Callback<void> callback)
{
  m_linkChanges.ConnectWithoutContext (callback);
}
bool
EyWifiNetDevice::IsBroadcast (void) const
{
  return true;
}
Address
EyWifiNetDevice::GetBroadcast (void) const
{
  return Mac48Address::GetBroadcast ();
}
bool
EyWifiNetDevice::IsMulticast (void) const
{
  return true;
}
Address
EyWifiNetDevice::GetMulticast (Ipv4Address multicastGroup) const
{
  return Mac48Address::GetMulticast (multicastGroup);
}
Address EyWifiNetDevice::GetMulticast (Ipv6Address addr) const
{
  return Mac48Address::GetMulticast (addr);
}
bool
EyWifiNetDevice::IsPointToPoint (void) const
{
  return false;
}
bool
EyWifiNetDevice::IsBridge (void) const
{
  return false;
}
bool
EyWifiNetDevice::Send (Ptr<Packet> packet, const Address& dest, uint16_t protocolNumber)
{
  NS_ASSERT (Mac48Address::IsMatchingType (dest));

  Mac48Address realTo = Mac48Address::ConvertFrom (dest);

  LlcSnapHeader llc;
  llc.SetType (protocolNumber);
  packet->AddHeader (llc);

  m_mac->NotifyTx (packet);
  m_mac->Enqueue (packet, realTo);
  return true;
}
Ptr<Node>
EyWifiNetDevice::GetNode (void) const
{
  return m_node;
}
void
EyWifiNetDevice::SetNode (Ptr<Node> node)
{
  m_node = node;
  CompleteConfig ();
}
bool
EyWifiNetDevice::NeedsArp (void) const
{
  return true;
}
void
EyWifiNetDevice::SetReceiveCallback (NetDevice::ReceiveCallback cb)
{
  m_forwardUp = cb;
}

void
EyWifiNetDevice::ForwardUp (Ptr<Packet> packet, Mac48Address from, Mac48Address to)
{
  LlcSnapHeader llc;
  packet->RemoveHeader (llc);
  enum NetDevice::PacketType type;
  if (to.IsBroadcast ())
    {
      type = NetDevice::PACKET_BROADCAST;
    }
  else if (to.IsGroup ())
    {
      type = NetDevice::PACKET_MULTICAST;
    }
  else if (to == m_mac->GetAddress ())
    {
      type = NetDevice::PACKET_HOST;
    }
  else
    {
      type = NetDevice::PACKET_OTHERHOST;
    }

  if (type != NetDevice::PACKET_OTHERHOST)
    {
      m_mac->NotifyRx (packet);
      m_forwardUp (this, packet, llc.GetType (), from);
    }

  if (!m_promiscRx.IsNull ())
    {
      m_mac->NotifyPromiscRx (packet);
      m_promiscRx (this, packet, llc.GetType (), from, to, type);
    }
}

void
EyWifiNetDevice::LinkUp (void)
{
  m_linkUp = true;
  m_linkChanges ();
}
void
EyWifiNetDevice::LinkDown (void)
{
  m_linkUp = false;
  m_linkChanges ();
}

bool
EyWifiNetDevice::SendFrom (Ptr<Packet> packet, const Address& source, const Address& dest, uint16_t protocolNumber)
{
  NS_ASSERT (Mac48Address::IsMatchingType (dest));
  NS_ASSERT (Mac48Address::IsMatchingType (source));

  Mac48Address realTo = Mac48Address::ConvertFrom (dest);
  Mac48Address realFrom = Mac48Address::ConvertFrom (source);

  LlcSnapHeader llc;
  llc.SetType (protocolNumber);
  packet->AddHeader (llc);

  m_mac->NotifyTx (packet);
  m_mac->Enqueue (packet, realTo, realFrom);

  return true;
}

void
EyWifiNetDevice::SetPromiscReceiveCallback (PromiscReceiveCallback cb)
{
  m_promiscRx = cb;
  m_mac->SetPromisc();
}

bool
EyWifiNetDevice::SupportsSendFrom (void) const
{
  return m_mac->SupportsSendFrom ();
}

} // namespace ns3

