/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2003,2007 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */

#include "ey-amrr-wifi-manager.h"
#include "ns3/simulator.h"
#include "ns3/log.h"
#include "ns3/uinteger.h"
#include "ns3/double.h"

NS_LOG_COMPONENT_DEFINE ("EyAmrrWifiRemoteStation");

namespace ns3 {

struct EyAmrrWifiRemoteStation : public EyWifiRemoteStation
{
  Time m_nextModeUpdate;
  uint32_t m_tx_ok;
  uint32_t m_tx_err;
  uint32_t m_tx_retr;
  uint32_t m_retry;
  uint32_t m_txrate;
  uint32_t m_successThreshold;
  uint32_t m_success;
  bool m_recovery;
};


NS_OBJECT_ENSURE_REGISTERED (EyAmrrWifiManager);

TypeId
EyAmrrWifiManager::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyAmrrWifiManager")
    .SetParent<EyWifiRemoteStationManager> ()
    .AddConstructor<EyAmrrWifiManager> ()
    .AddAttribute ("UpdatePeriod",
                   "The interval between decisions about rate control changes",
                   TimeValue (Seconds (1.0)),
                   MakeTimeAccessor (&EyAmrrWifiManager::m_updatePeriod),
                   MakeTimeChecker ())
    .AddAttribute ("FailureRatio",
                   "Ratio of minimum erroneous transmissions needed to switch to a lower rate",
                   DoubleValue (1.0 / 3.0),
                   MakeDoubleAccessor (&EyAmrrWifiManager::m_failureRatio),
                   MakeDoubleChecker<double> (0.0, 1.0))
    .AddAttribute ("SuccessRatio",
                   "Ratio of maximum erroneous transmissions needed to switch to a higher rate",
                   DoubleValue (1.0 / 10.0),
                   MakeDoubleAccessor (&EyAmrrWifiManager::m_successRatio),
                   MakeDoubleChecker<double> (0.0, 1.0))
    .AddAttribute ("MaxSuccessThreshold",
                   "Maximum number of consecutive success periods needed to switch to a higher rate",
                   UintegerValue (10),
                   MakeUintegerAccessor (&EyAmrrWifiManager::m_maxSuccessThreshold),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("MinSuccessThreshold",
                   "Minimum number of consecutive success periods needed to switch to a higher rate",
                   UintegerValue (1),
                   MakeUintegerAccessor (&EyAmrrWifiManager::m_minSuccessThreshold),
                   MakeUintegerChecker<uint32_t> ())
  ;
  return tid;
}

EyAmrrWifiManager::EyAmrrWifiManager ()
{
}

EyWifiRemoteStation *
EyAmrrWifiManager::DoCreateStation (void) const
{
  EyAmrrWifiRemoteStation *station = new EyAmrrWifiRemoteStation ();
  station->m_nextModeUpdate = Simulator::Now () + m_updatePeriod;
  station->m_tx_ok = 0;
  station->m_tx_err = 0;
  station->m_tx_retr = 0;
  station->m_retry = 0;
  station->m_txrate = 0;
  station->m_successThreshold = m_minSuccessThreshold;
  station->m_success = 0;
  station->m_recovery = false;
  return station;
}


void
EyAmrrWifiManager::DoReportRxOk (EyWifiRemoteStation *station,
                               double rxSnr, EyWifiMode txMode)
{
}
void
EyAmrrWifiManager::DoReportRtsFailed (EyWifiRemoteStation *station)
{
}
void
EyAmrrWifiManager::DoReportDataFailed (EyWifiRemoteStation *st)
{
  EyAmrrWifiRemoteStation *station = (EyAmrrWifiRemoteStation *)st;
  station->m_retry++;
  station->m_tx_retr++;
}
void
EyAmrrWifiManager::DoReportRtsOk (EyWifiRemoteStation *st,
                                double ctsSnr, EyWifiMode ctsMode, double rtsSnr)
{
}
void
EyAmrrWifiManager::DoReportDataOk (EyWifiRemoteStation *st,
                                 double ackSnr, EyWifiMode ackMode, double dataSnr)
{
  EyAmrrWifiRemoteStation *station = (EyAmrrWifiRemoteStation *)st;
  station->m_retry = 0;
  station->m_tx_ok++;
}
void
EyAmrrWifiManager::DoReportFinalRtsFailed (EyWifiRemoteStation *station)
{
}
void
EyAmrrWifiManager::DoReportFinalDataFailed (EyWifiRemoteStation *st)
{
  EyAmrrWifiRemoteStation *station = (EyAmrrWifiRemoteStation *)st;
  station->m_retry = 0;
  station->m_tx_err++;
}
bool
EyAmrrWifiManager::IsMinRate (EyAmrrWifiRemoteStation *station) const
{
  return (station->m_txrate == 0);
}
bool
EyAmrrWifiManager::IsMaxRate (EyAmrrWifiRemoteStation *station) const
{
  NS_ASSERT (station->m_txrate + 1 <= GetNSupported (station));
  return (station->m_txrate + 1 == GetNSupported (station));
}
bool
EyAmrrWifiManager::IsSuccess (EyAmrrWifiRemoteStation *station) const
{
  return (station->m_tx_retr + station->m_tx_err) < station->m_tx_ok * m_successRatio;
}
bool
EyAmrrWifiManager::IsFailure (EyAmrrWifiRemoteStation *station) const
{
  return (station->m_tx_retr + station->m_tx_err) > station->m_tx_ok * m_failureRatio;
}
bool
EyAmrrWifiManager::IsEnough (EyAmrrWifiRemoteStation *station) const
{
  return (station->m_tx_retr + station->m_tx_err + station->m_tx_ok) > 10;
}
void
EyAmrrWifiManager::ResetCnt (EyAmrrWifiRemoteStation *station)
{
  station->m_tx_ok = 0;
  station->m_tx_err = 0;
  station->m_tx_retr = 0;
}
void
EyAmrrWifiManager::IncreaseRate (EyAmrrWifiRemoteStation *station)
{
  station->m_txrate++;
  NS_ASSERT (station->m_txrate < GetNSupported (station));
}
void
EyAmrrWifiManager::DecreaseRate (EyAmrrWifiRemoteStation *station)
{
  station->m_txrate--;
}

void
EyAmrrWifiManager::UpdateMode (EyAmrrWifiRemoteStation *station)
{
  if (Simulator::Now () < station->m_nextModeUpdate)
    {
      return;
    }
  station->m_nextModeUpdate = Simulator::Now () + m_updatePeriod;
  NS_LOG_DEBUG ("Update");

  bool needChange = false;

  if (IsSuccess (station) && IsEnough (station))
    {
      station->m_success++;
      NS_LOG_DEBUG ("++ success=" << station->m_success << " successThreshold=" << station->m_successThreshold <<
                    " tx_ok=" << station->m_tx_ok << " tx_err=" << station->m_tx_err << " tx_retr=" << station->m_tx_retr <<
                    " rate=" << station->m_txrate << " n-supported-rates=" << GetNSupported (station));
      if (station->m_success >= station->m_successThreshold
          && !IsMaxRate (station))
        {
          station->m_recovery = true;
          station->m_success = 0;
          IncreaseRate (station);
          needChange = true;
        }
      else
        {
          station->m_recovery = false;
        }
    }
  else if (IsFailure (station))
    {
      station->m_success = 0;
      NS_LOG_DEBUG ("-- success=" << station->m_success << " successThreshold=" << station->m_successThreshold <<
                    " tx_ok=" << station->m_tx_ok << " tx_err=" << station->m_tx_err << " tx_retr=" << station->m_tx_retr <<
                    " rate=" << station->m_txrate << " n-supported-rates=" << GetNSupported (station));
      if (!IsMinRate (station))
        {
          if (station->m_recovery)
            {
              station->m_successThreshold *= 2;
              station->m_successThreshold = std::min (station->m_successThreshold,
                                                      m_maxSuccessThreshold);
            }
          else
            {
              station->m_successThreshold = m_minSuccessThreshold;
            }
          station->m_recovery = false;
          DecreaseRate (station);
          needChange = true;
        }
      else
        {
          station->m_recovery = false;
        }
    }
  if (IsEnough (station) || needChange)
    {
      NS_LOG_DEBUG ("Reset");
      ResetCnt (station);
    }
}
EyWifiMode
EyAmrrWifiManager::DoGetDataMode (EyWifiRemoteStation *st, uint32_t size)
{
  EyAmrrWifiRemoteStation *station = (EyAmrrWifiRemoteStation *)st;
  UpdateMode (station);
  NS_ASSERT (station->m_txrate < GetNSupported (station));
  uint32_t rateIndex;
  if (station->m_retry < 1)
    {
      rateIndex = station->m_txrate;
    }
  else if (station->m_retry < 2)
    {
      if (station->m_txrate > 0)
        {
          rateIndex = station->m_txrate - 1;
        }
      else
        {
          rateIndex = station->m_txrate;
        }
    }
  else if (station->m_retry < 3)
    {
      if (station->m_txrate > 1)
        {
          rateIndex = station->m_txrate - 2;
        }
      else
        {
          rateIndex = station->m_txrate;
        }
    }
  else
    {
      if (station->m_txrate > 2)
        {
          rateIndex = station->m_txrate - 3;
        }
      else
        {
          rateIndex = station->m_txrate;
        }
    }

  return GetSupported (station, rateIndex);
}
EyWifiMode
EyAmrrWifiManager::DoGetRtsMode (EyWifiRemoteStation *st)
{
  EyAmrrWifiRemoteStation *station = (EyAmrrWifiRemoteStation *)st;
  UpdateMode (station);
  // XXX: can we implement something smarter ?
  return GetSupported (station, 0);
}


bool
EyAmrrWifiManager::IsLowLatency (void) const
{
  return true;
}

} // namespace ns3
