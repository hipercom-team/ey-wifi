/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2004,2005,2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */

#include "ey-aarf-wifi-manager.h"

#include "ns3/double.h"
#include "ns3/uinteger.h"
#include "ns3/log.h"

#define Min(a,b) ((a < b) ? a : b)
#define Max(a,b) ((a > b) ? a : b)

NS_LOG_COMPONENT_DEFINE ("EyAarfWifiManager");

namespace ns3 {

struct EyAarfWifiRemoteStation : public EyWifiRemoteStation
{
  uint32_t m_timer;
  uint32_t m_success;
  uint32_t m_failed;
  bool m_recovery;
  uint32_t m_retry;

  uint32_t m_timerTimeout;
  uint32_t m_successThreshold;

  uint32_t m_rate;
};


NS_OBJECT_ENSURE_REGISTERED (EyAarfWifiManager);

TypeId
EyAarfWifiManager::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyAarfWifiManager")
    .SetParent<EyWifiRemoteStationManager> ()
    .AddConstructor<EyAarfWifiManager> ()
    .AddAttribute ("SuccessK", "Multiplication factor for the success threshold in the AARF algorithm.",
                   DoubleValue (2.0),
                   MakeDoubleAccessor (&EyAarfWifiManager::m_successK),
                   MakeDoubleChecker<double> ())
    .AddAttribute ("TimerK",
                   "Multiplication factor for the timer threshold in the AARF algorithm.",
                   DoubleValue (2.0),
                   MakeDoubleAccessor (&EyAarfWifiManager::m_timerK),
                   MakeDoubleChecker<double> ())
    .AddAttribute ("MaxSuccessThreshold",
                   "Maximum value of the success threshold in the AARF algorithm.",
                   UintegerValue (60),
                   MakeUintegerAccessor (&EyAarfWifiManager::m_maxSuccessThreshold),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("MinTimerThreshold",
                   "The minimum value for the 'timer' threshold in the AARF algorithm.",
                   UintegerValue (15),
                   MakeUintegerAccessor (&EyAarfWifiManager::m_minTimerThreshold),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("MinSuccessThreshold",
                   "The minimum value for the success threshold in the AARF algorithm.",
                   UintegerValue (10),
                   MakeUintegerAccessor (&EyAarfWifiManager::m_minSuccessThreshold),
                   MakeUintegerChecker<uint32_t> ())
  ;
  return tid;
}

EyAarfWifiManager::EyAarfWifiManager ()
{
}
EyAarfWifiManager::~EyAarfWifiManager ()
{
}

EyWifiRemoteStation *
EyAarfWifiManager::DoCreateStation (void) const
{
  EyAarfWifiRemoteStation *station = new EyAarfWifiRemoteStation ();

  station->m_successThreshold = m_minSuccessThreshold;
  station->m_timerTimeout = m_minTimerThreshold;
  station->m_rate = 0;
  station->m_success = 0;
  station->m_failed = 0;
  station->m_recovery = false;
  station->m_retry = 0;
  station->m_timer = 0;

  return station;
}

void
EyAarfWifiManager::DoReportRtsFailed (EyWifiRemoteStation *station)
{
}
/**
 * It is important to realize that "recovery" mode starts after failure of
 * the first transmission after a rate increase and ends at the first successful
 * transmission. Specifically, recovery mode transcends retransmissions boundaries.
 * Fundamentally, ARF handles each data transmission independently, whether it
 * is the initial transmission of a packet or the retransmission of a packet.
 * The fundamental reason for this is that there is a backoff between each data
 * transmission, be it an initial transmission or a retransmission.
 */
void
EyAarfWifiManager::DoReportDataFailed (EyWifiRemoteStation *st)
{
  EyAarfWifiRemoteStation *station = (EyAarfWifiRemoteStation *)st;
  station->m_timer++;
  station->m_failed++;
  station->m_retry++;
  station->m_success = 0;

  if (station->m_recovery)
    {
      NS_ASSERT (station->m_retry >= 1);
      if (station->m_retry == 1)
        {
          // need recovery fallback
          station->m_successThreshold = (int)(Min (station->m_successThreshold * m_successK,
                                                   m_maxSuccessThreshold));
          station->m_timerTimeout = (int)(Max (station->m_timerTimeout * m_timerK,
                                               m_minSuccessThreshold));
          if (station->m_rate != 0)
            {
              station->m_rate--;
            }
        }
      station->m_timer = 0;
    }
  else
    {
      NS_ASSERT (station->m_retry >= 1);
      if (((station->m_retry - 1) % 2) == 1)
        {
          // need normal fallback
          station->m_timerTimeout = m_minTimerThreshold;
          station->m_successThreshold = m_minSuccessThreshold;
          if (station->m_rate != 0)
            {
              station->m_rate--;
            }
        }
      if (station->m_retry >= 2)
        {
          station->m_timer = 0;
        }
    }
}
void
EyAarfWifiManager::DoReportRxOk (EyWifiRemoteStation *station,
                               double rxSnr, EyWifiMode txMode)
{
}
void
EyAarfWifiManager::DoReportRtsOk (EyWifiRemoteStation *station,
                                double ctsSnr, EyWifiMode ctsMode, double rtsSnr)
{
  NS_LOG_DEBUG ("station=" << station << " rts ok");
}
void
EyAarfWifiManager::DoReportDataOk (EyWifiRemoteStation *st,
                                 double ackSnr, EyWifiMode ackMode, double dataSnr)
{
  EyAarfWifiRemoteStation *station = (EyAarfWifiRemoteStation *) st;
  station->m_timer++;
  station->m_success++;
  station->m_failed = 0;
  station->m_recovery = false;
  station->m_retry = 0;
  NS_LOG_DEBUG ("station=" << station << " data ok success=" << station->m_success << ", timer=" << station->m_timer);
  if ((station->m_success == station->m_successThreshold
       || station->m_timer == station->m_timerTimeout)
      && (station->m_rate < (GetNSupported (station) - 1)))
    {
      NS_LOG_DEBUG ("station=" << station << " inc rate");
      station->m_rate++;
      station->m_timer = 0;
      station->m_success = 0;
      station->m_recovery = true;
    }
}
void
EyAarfWifiManager::DoReportFinalRtsFailed (EyWifiRemoteStation *station)
{
}
void
EyAarfWifiManager::DoReportFinalDataFailed (EyWifiRemoteStation *station)
{
}

EyWifiMode
EyAarfWifiManager::DoGetDataMode (EyWifiRemoteStation *st, uint32_t size)
{
  EyAarfWifiRemoteStation *station = (EyAarfWifiRemoteStation *) st;
  return GetSupported (station, station->m_rate);
}
EyWifiMode
EyAarfWifiManager::DoGetRtsMode (EyWifiRemoteStation *st)
{
  // XXX: we could/should implement the Aarf algorithm for
  // RTS only by picking a single rate within the BasicRateSet.
  EyAarfWifiRemoteStation *station = (EyAarfWifiRemoteStation *) st;
  return GetSupported (station, 0);
}

bool
EyAarfWifiManager::IsLowLatency (void) const
{
  return true;
}

} // namespace ns3
