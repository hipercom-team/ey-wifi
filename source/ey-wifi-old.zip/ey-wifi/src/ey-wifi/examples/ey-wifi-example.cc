/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2008 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <Hana.Baccouch@inria.fr>
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/ey-wifi-module.h"

using namespace ns3;

/**
 * \brief Test script.
 * 
 * This example creates one dimensional grid topology and then nodes send periodically broadcast messages.
 * 
 * [10.0.0.1] <-- step --> [10.0.0.2] <-- step --> [10.0.0.3]
 * 
 * Broadcast packets
 */
void 
GeneratePackets(Ptr<Socket> socket, uint32_t pktSize,
                     uint32_t pktCount, Time pktInterval) 
{
  if (pktCount > 0)
    {
      socket->Send(Create<Packet>(pktSize));
      Simulator::Schedule(pktInterval, &GeneratePackets, socket, pktSize,
                          pktCount - 1, pktInterval);
      Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
    }
  else
    {
      socket->Close();
    }
}

void
ReceivePacket(Ptr<Socket> socket)
{
  Address sourceAddress;
  Ptr<Packet> p = socket->RecvFrom(sourceAddress);
  InetSocketAddress inetSourceAddr = InetSocketAddress::ConvertFrom(
                                                                    sourceAddress);
  Ipv4Address sender = inetSourceAddr.GetIpv4();
  Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
  Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
  Ipv4Address addri = iaddr.GetLocal();
  NS_LOG_UNCOND(Simulator::Now().GetNanoSeconds()<<" ns Node "<<sender<<" received packet from node "<<addri);
}

int
main(int argc, char **argv)
{
  // Number of nodes
  uint32_t size=3;
  // Distance between nodes
  double step=10; // meters
  // Simulation time
  double totalTime=10; // seconds
  // Scheduler timer
  Timer m_timer(Timer::CANCEL_ON_DESTROY);
  int port=80; 
  uint32_t packetSize= 1000; // bytes
  uint32_t numPackets = 10;
  double interval= 1.0; // seconds
  //Network
  NodeContainer nodes;
  NetDeviceContainer devices;
  Ipv4InterfaceContainer interfaces;
    
  CommandLine cmd;
  cmd.AddValue("size", "Number of nodes.", size);
  cmd.AddValue("time", "Simulation time, s.", totalTime);
  cmd.AddValue("step", "Grid step, m", step);
  cmd.AddValue ("packetSize", "size of application packet sent", packetSize);
  cmd.AddValue ("numPackets", "number of packets generated", numPackets);
  cmd.AddValue ("interval", "interval (seconds) between packets", interval);
  cmd.Parse(argc, argv);
	
  // Create nodes
  nodes.Create(size);
  // Create static grid
  MobilityHelper mobility;
  mobility.SetPositionAllocator("ns3::GridPositionAllocator", "MinX",
                                DoubleValue(0.0), "MinY", DoubleValue(0.0), "DeltaX",
                                DoubleValue(step), "DeltaY", DoubleValue(step), "GridWidth",
                                UintegerValue(5), "LayoutType", StringValue("RowFirst"));
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(nodes);
  
  // Create devices
  EyYansWifiPhyHelper wifiPhy;
  wifiPhy.SetErrorRateModel("ns3::EyYansErrorRateModel");
  
  EyYansWifiChannelHelper wifiChannel = EyYansWifiChannelHelper::Default();
  wifiPhy.SetChannel(wifiChannel.Create());
  
  EyNqosWifiMacHelper wifiMac = EyNqosWifiMacHelper::Default();
  wifiMac.SetType("ns3::EyAdhocWifiMac");
  
  EyWifiHelper wifi = EyWifiHelper::Default();
  // Use burst mode
  wifi.SetRemoteStationManager("ns3::EyConstantRateWifiManager", "BurstMode",
                               BooleanValue(true));
  
  devices = wifi.Install(wifiPhy, wifiMac, nodes);
  
  // Install internet stacks
  InternetStackHelper stack;
  stack.Install(nodes);
  Ipv4AddressHelper address;
  address.SetBase("10.0.0.0", "255.0.0.0");
  interfaces = address.Assign(devices);
  TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
  
  // Install applications
  // Reception
  for (int i = 0; i < int(size); i++) {
    Ptr<Socket> recvSink = Socket::CreateSocket(nodes.Get(i), tid);
    InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(),
                                                port);
    recvSink->Bind(local);
    recvSink->SetRecvCallback(MakeCallback(&ReceivePacket));
  }
  
  // Transmission
  for (int i = 0; i < int(size); i++) 
    {
      Ptr<Socket> source = Socket::CreateSocket(nodes.Get(i), tid);
      InetSocketAddress remote = InetSocketAddress(Ipv4Address("255.255.255.255"), port);
      source->Connect(remote);
      source->SetAllowBroadcast(true);
      Simulator::Schedule(Seconds(1), &GeneratePackets, 
                          source, packetSize, numPackets, Seconds(interval));
      
    }
  Simulator::Stop(Seconds(totalTime));
  Simulator::Run();
  Simulator::Destroy();
  return 0;
}
