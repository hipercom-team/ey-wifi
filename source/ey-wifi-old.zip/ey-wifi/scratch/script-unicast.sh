#!/bin/sh
INTERVAL="1000 700 500 300 130 50 40 30 20 10 5 4 3"
plotEyWifi=""
plotWifi=""
eywifi=""
wifi=""

#simulation
for inter in  $INTERVAL
do
    eywifi=$(./waf --run "scratch/ey-wifi-unicast --interval=$inter" 2> "ey-wifi-unicast-$inter.dat")
    plotEyWifi="$plotEyWifi$eywifi\n"
    eywifi=""
    
    wifi=$(./waf --run "scratch/wifi-unicast --interval=$inter" 2> "wifi-unicast-$inter.dat")
    plotWifi="$plotWifi$wifi\n"
    wifi=""
done

echo -e $plotEyWifi > eywifi-unicast-results.tr
echo -e $plotWifi > wifi-unicast-results.tr

STEP="20 17 12 10 7 5 4 3 2 1"
plotEyWifi=""
plotWifi=""
eywifi=""
wifi=""

#Simulation
for step in  $STEP
do
    eywifi=$(./waf --run "scratch/ey-wifi-unicast --step=$step" 2> "ey-wifi-unicast-density-$step.dat")
    plotEyWifi="$plotEyWifi$eywifi\n"
    eywifi=""

    wifi=$(./waf --run "scratch/wifi-unicast --step=$step" 2> "wifi-unicast-density-$step.dat")
    plotWifi="$plotWifi$wifi\n"
    wifi=""
done

echo -e $plotEyWifi > eywifi-unicast-results-density.tr
echo -e $plotWifi > wifi-unicast-results-density.tr

#Plot
gnuplot "scratch/plot-unicast.gp"
okular unicast-packets-received.jpeg
okular unicast-packets-received-density.jpeg
