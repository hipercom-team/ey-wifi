import os, re
from PIL import Image, ImageDraw

fileName="channel-log.dat"
#131 0.025127 BurstEnd 13
rEx=re.compile("([0-9]+) *. ([0-9]+)")
def readNodeLog(fileName):
    f = open(fileName)
    states ={0:None}
    startClock={} 
    result = {}
    
    while True:
        line = f.readline()
        if line == "":
            break # end loop
        m_rec=rEx.search(line)
        if m_rec ==None:
            continue
        infoList = line.strip().split()
        nodeId = int(infoList[0]) # NodeID
        clock = float(infoList[1]) # time
        event = infoList[2] # data or burst
        slots = infoList[3] # 0 1

        
        if states.has_key(nodeId)== False:            
            states[nodeId]=None
            startClock[nodeId]=None
        
        if result.has_key(nodeId)==False:
            result[nodeId]=[]
            
        if states[nodeId] == None:
            assert event in ["BurstBegin", "PhyTxBegin"]           
            if event == "BurstBegin":
                states[nodeId] = "burst"
                startClock[nodeId] = clock
            elif event == "PhyTxBegin":
                states[nodeId] = "data"
                startClock[nodeId] = clock
            else: raise ValueError("event", event)     
        
        elif states[nodeId] == "burst":
            assert event == "BurstEnd"
            
            #print event, nodeId, result[nodeId]
            result[nodeId].append(( "burst", startClock[nodeId], clock))
            #print nodeId ,result[nodeId]
            states[nodeId] = None
            startClock [nodeId]= None
     
        elif states[nodeId] == "data":
            assert event == "PhyTxEnd"
            result[nodeId].append(("data", startClock[nodeId], clock))
            states[nodeId] = None
            startClock [nodeId]= None
        else: raise ValueError("state", states[nodeId])
        
       
   
    #print result[3]
    return result


white = (255,255,255)
black = (0,0,0)
red = (128, 0, 0)

def getNodeColor(nodeId, nbNode):
    minColor = 50
    maxColor = 255
    coef = (maxColor-minColor) /float (nbNode-1)
    return int(nodeId * coef + minColor)

def processSimul(fileName):   
    
    logOfNodes=readNodeLog(fileName)
    nodeList = sorted(logOfNodes.keys())
    #print logOfNodes
    xSize = 1600
    xSize = 1111
    ySize = 30000
    timeStep = 0.000009
    image = Image.new("RGB", (xSize, ySize), white)

    nbNode = len(nodeList)

    cySize = ySize//(nbNode+1)

    selectedNodeList = nodeList
    #selectedNodeList = [14, 17]
    draw = ImageDraw.Draw(image)
    for cy in range(0, cySize):
        #y = cy*(nbNode+1)+nbNode
        n = len(selectedNodeList)
        y = cy*(n+1)+n
        draw.line((0,y)+(xSize-1, y), red)
    
    def drawLine(nodeId, xStart, xStop, color, info = None, dbgList = [],
                 selectedNodeList = None):
        if selectedNodeList == None:
            selectedNbNode = nbNode
        else:
            if nodeId not in selectedNodeList:
                return None
            selectedNbNode = len(selectedNodeList)
            nodeId = selectedNodeList.index(nodeId)
        result = None
        if xStart <0 or xStop <0:
            return
        cyStart = xStart // xSize
        cyStop = xStop // xSize
        x1 = xStart % xSize
        x2 = xStop % xSize
        #print "draw", (x1,cyStart),(x2,cyStop),color
        if cyStop >= cySize:
            return

        if cyStart == cyStop:
            y = cyStart*(selectedNbNode+1) + nodeId
            assert x1 <= x2
            draw.line((x1,y)+(x2,y), color)
            for dx,dy in dbgList:
                if x1 <= dx <= x2 and dy == y:
                    result = (dx,dy)
        else:
            for cy in range(cyStart, cyStop+1):
                y = cy*(selectedNbNode+1) + nodeId
                if cy == cyStart:
                    draw.line((x1,y)+(xSize-1,y), color)
                elif cy == cyStop:
                    draw.line((0,y)+(x2,y), color)
                else: draw.line((0,y)+(xSize-1,y), color)

        return result
                    
        #print "draw", (x1,cyStart),(x2,cyStop),color
        #print "draw", nodeId, (y,x1,x2), cyStart, xStart, xStop, info
        #print "draw", (x1,y),(x2,y),color


    #clockOffset = 2.11
    clockOffset = 0.0
        
    #dbgList = [(825,1998), (830, 2001)]
    #dbgList = [(1029,726), (1039,726), (1030,727)]
    dbgList = [(220,3792), (122,3974), (465,14871)]
    
    for nodeId in nodeList:
        color = getNodeColor(nodeId, nbNode)
        for (txType, start, stop) in logOfNodes[nodeId]:
            if txType == "burst": fullColor = (0, 0, color)
            elif txType == "data": fullColor = (0, color, 0)
            else: raise ValueError("txType", txType)
            info = (start, stop)
            start -= clockOffset
            stop -= clockOffset
            xStart = int(start / timeStep)
            xStop = int(stop / timeStep)

            dbg = drawLine(nodeId, xStart, xStop, fullColor, info, dbgList,
                           selectedNodeList)
            if dbg != None:
                print "dbg", nodeId, (txType, start, stop), dbg

    image.save("ey-wifi-channel.png")

processSimul(fileName)