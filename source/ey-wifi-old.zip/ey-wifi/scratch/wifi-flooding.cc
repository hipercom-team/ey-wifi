/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2008 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <Hana.Baccouch@inria.fr>
 */
 
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/ey-wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/flow-monitor-helper.h"
#include <iomanip>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("WifiFloodingExample");
/// Tag 
struct MyPacketTag : public Tag
{
  uint32_t pid;
  
  MyPacketTag (uint32_t o = -1) : Tag (), pid (o) {}

  static TypeId GetTypeId ()
  {
    static TypeId tid = TypeId ("ns3::MyPacketTag").SetParent<Tag> ();
    return tid;
  }

  TypeId  GetInstanceTypeId () const 
  {
    return GetTypeId ();
  }

  uint32_t GetSerializedSize () const
  {
    return sizeof(uint32_t);
  }
  uint32_t GetValue () const
  {
    return pid;
  }
  void  Serialize (TagBuffer i) const
  {
    i.WriteU32 (pid);
  }

  void  Deserialize (TagBuffer i)
  {
    pid = i.ReadU32 ();
  }

  void  Print (std::ostream &os) const
  {
    std::cout << "Flooding "<< pid<<"\n";
  }
};

class Flooding
{
public:
  uint32_t receivedApp;
  uint32_t sentApp;
  uint32_t tag;
  std::map<double ,uint32_t> map_distance; 
  std::map<Ptr<Node>,std::vector<uint32_t> > map_nodes; 
  Flooding();
  /// Configure script parameters, \return true on successful configuration
  bool Configure(int argc, char **argv);
  /// Run simulation
  void Run();
  void GetStatistics(void);
  
private:
  ///\name parameters
  //\{
  /// Number of nodes
  uint32_t size;
  /// Distance between nodes, meters
  double step;
  /// Simulation time, seconds
  double totalTime; //MilliSeconds
  /// Scheduler timer
  Timer m_timer;
  int port; 
  uint32_t packetSize; // = 1000; // bytes
  uint32_t numPackets; // = 50 000 packtes
  double interval; //  µSeconds
  int txPackets;
  int packetReceived;
  Ipv4Address destination;
  //\}
  
  ///\name network
  //\{
  NodeContainer nodes;
  NetDeviceContainer devices;
  Ipv4InterfaceContainer interfaces;
  //\}
  
private:
  void CreateNodes();
  void CreateDevices();
  void InstallInternetStack();
  void InstallApplications();
  void GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                       uint32_t pktCount, Time pktInterval);
  void ReceivePacket(Ptr<Socket> socket);
  void WifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p); 
  void WifiMacTxBeginTrace(std::string context, Ptr<const Packet> p);	
  void WifiPhyRxDrop(std::string context,
                       Ptr<const Packet> p);
  void WifiPhyRxEndTrace(std::string context, Ptr<const Packet> p) ;
  Vector GetPosition(Ptr<Node> node) ;
};

int
main(int argc, char **argv) 
{
  Flooding test;
  if (!test.Configure(argc, argv))
    NS_FATAL_ERROR("Configuration failed. Aborted."); 
  test.Run();
  test.GetStatistics();
  return 0;
}

//-----------------------------------------------------------------------------
Flooding::Flooding() :
  size(200),
  step(10),
  totalTime(10),
  m_timer(Timer::CANCEL_ON_DESTROY),
  port(80),
  packetSize(1000), 
  numPackets(50000),
  interval(5)
{
  txPackets=0;
  packetReceived=0;

  receivedApp=0;
  sentApp=0;
  destination=Ipv4Address("255.255.255.255");
  tag=0;
}
void
Flooding::GetStatistics(void)
{
  float load= (size*1000/interval)*packetSize/8 ;
  load=load/(6*1024*1024);
  
  std::cout<<interval <<" "<<load<< " " <<step<<" "<< std::setprecision(4)<< (size)/float(step *4*50*step)<<" "
           << packetReceived<<" "<<(packetReceived/totalTime)/size<< " " 
           << txPackets <<" "
           <<packetReceived/float(txPackets) <<"\n";
           
}
bool 
Flooding::Configure(int argc, char **argv) 
{
  SeedManager::SetSeed(12345);
  CommandLine cmd;
  cmd.AddValue("size", "Number of nodes.", size);
  cmd.AddValue("time", "Simulation time, s.", totalTime);
  cmd.AddValue("step", "Grid step, m", step);
  cmd.AddValue ("packetSize", "size of application packet sent", packetSize);
  cmd.AddValue ("numPackets", "number of packets generated", numPackets);
  cmd.AddValue ("interval", "interval (MilliSeconds) between packets", interval);
  cmd.Parse(argc, argv);
  return true;
}
void
Flooding::Run() 
{  
  Config::SetDefault("ns3::WifiRemoteStationManager::MaxSlrc",
                     UintegerValue(10));
  CreateNodes();
  CreateDevices();
  InstallInternetStack();
  InstallApplications();
  Simulator::Stop(Seconds(totalTime));
  Simulator::Run();
  Simulator::Destroy();
}
void
Flooding::CreateNodes() 
{ 
  nodes.Create(size);
  // Create static grid
  MobilityHelper mobility;
  mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
				 "MinX", DoubleValue (0.0),
				 "MinY", DoubleValue (0.0),
				 "DeltaX", DoubleValue (step),
				 "DeltaY", DoubleValue (step),
				 "GridWidth", UintegerValue (4),
				 "LayoutType", StringValue ("RowFirst"));
  mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
  mobility.Install(nodes);
}
void
Flooding::CreateDevices() 
{ 
  EyNqosWifiMacHelper wifiMac = EyNqosWifiMacHelper::Default();
  wifiMac.SetType("ns3::EyAdhocWifiMac");
  EyYansWifiPhyHelper wifiPhy;
  wifiPhy.SetErrorRateModel("ns3::EyYansErrorRateModel");
  EyYansWifiChannelHelper wifiChannel = EyYansWifiChannelHelper::Default();
  wifiPhy.SetChannel(wifiChannel.Create());
  EyWifiHelper wifi = EyWifiHelper::Default();
  wifi.SetRemoteStationManager("ns3::EyConstantRateWifiManager","DataMode", StringValue ("OfdmRate6Mbps"),  "BurstMode", BooleanValue(false));
  devices = wifi.Install(wifiPhy, wifiMac, nodes);
  //PhyTxBegin
  std::ostringstream pathTxBegin;
  pathTxBegin<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyTxBegin";	
  Config::Connect(pathTxBegin.str(),
                  MakeCallback(&Flooding::WifiPhyTxBeginTrace,this));

  //PhyRXEnd                
  std::ostringstream pathPhyRXEnd;
  pathPhyRXEnd<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyRxEnd";           
  Config::Connect(pathPhyRXEnd.str(),
                  MakeCallback(&Flooding::WifiPhyRxEndTrace,this));
}
void
Flooding::InstallInternetStack() 
{
  InternetStackHelper stack;
  stack.Install(nodes);
  Ipv4AddressHelper address;
  address.SetBase("10.0.0.0", "255.0.0.0");
  interfaces = address.Assign(devices);
}

void 
Flooding::InstallApplications() 
{
  TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
  //Reception
  for (int i = 0; i < int(size); i++) 
    {
      Ptr<Socket> recvSink = Socket::CreateSocket(nodes.Get(i), tid);
      InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(),
                                                  port);
      recvSink->Bind(local);
      recvSink->SetRecvCallback(MakeCallback(&Flooding::ReceivePacket, this));
    }
  
   ExponentialVariable x(1000,1500);
   ExponentialVariable distInterval(interval,(interval*4)); //(mean, max value)
   //Transmission
   for (int i = 0; i < int(size); i++) 
     {
       Ptr<Socket> source = Socket::CreateSocket(nodes.Get(i), tid);
       InetSocketAddress remote = InetSocketAddress(
                                                    Ipv4Address("255.255.255.255"), port);
      source->Connect(remote);
      source->SetAllowBroadcast(true);
      int txBegin = x.GetValue();
      int pktInterval=distInterval.GetValue();
      //std::cout<<"\ntxbegin"<<txBegin;
      Simulator::Schedule(MilliSeconds(txBegin), &Flooding::GenerateTraffic, this,
                          source, packetSize, numPackets, MilliSeconds(pktInterval));    
     }
   
}
void
Flooding::GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                               uint32_t pktCount, Time pktInterval) 
{
  if (pktCount > 0) 
    {
      Ptr<Packet> p =Create<Packet>(pktSize);
      MyPacketTag myTag (tag);
      p->AddPacketTag (myTag); 
      socket->Send(p);
      Simulator::Schedule(pktInterval, &Flooding::GenerateTraffic, this, socket, pktSize,
                          pktCount - 1, pktInterval);
      Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
      Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
      Ipv4Address addri = iaddr.GetLocal();
      Ptr<Node> sender= ipv4->GetObject<Node> ();
      std::vector<uint32_t> v=map_nodes[sender];  
      v.push_back(myTag.GetValue ());
      map_nodes[sender]=v;
      NS_LOG_UNCOND (Simulator::Now().GetNanoSeconds()<<" Flooding "<< myTag.GetValue ()<<" "<<addri<<" Packet sent "<<p->GetUid());
      tag++;     
    }
  else
    {
      socket->Close();
    }
}

void 
Flooding::ReceivePacket(Ptr<Socket> socket) 
{
  Address sourceAddress;
  Ptr<Packet> p = socket->RecvFrom(sourceAddress);
  MyPacketTag rxTag;
  p->PeekPacketTag (rxTag);
  uint32_t size = p->GetSize ();
  uint8_t *buf = new uint8_t[size];
  p->CopyData(buf,size);  
  InetSocketAddress inetSourceAddr = InetSocketAddress::ConvertFrom(sourceAddress);
  Ipv4Address sender = inetSourceAddr.GetIpv4();
  Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
  Ptr<Node> receiver= ipv4->GetObject<Node> ();
  Vector receiverPos= GetPosition(receiver);
  Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
  Ipv4Address addri = iaddr.GetLocal();
  NS_LOG_UNCOND(Simulator::Now().GetNanoSeconds()<<" Flooding "<< rxTag.GetValue ()<<" "<<addri<<" Packet received from " <<sender<<" "<<p->GetUid());
  std::vector<uint32_t> v=map_nodes[receiver];  // Add PacketTags
  bool transmitted=false;
  for ( size_t i = 0, size = v.size(); i < size; ++i )
    {
      if (v[i]==(uint32_t)rxTag.GetValue())
        {
          transmitted=true;
          break;
        }
    }
  //Forwarding
  if(!transmitted)  
    {  
      
      Ptr<Socket> sce = Socket::CreateSocket(receiver, TypeId::LookupByName("ns3::UdpSocketFactory"));
      InetSocketAddress remote = InetSocketAddress(Ipv4Address("255.255.255.255"), port);
      sce->Connect(remote);
      sce->SetAllowBroadcast(true);
      Ptr<Packet> packet = Create<Packet>(buf, size);
      packet->AddPacketTag (rxTag); 
      sce->Send(packet);
      NS_LOG_UNCOND(Simulator::Now().GetNanoSeconds()<<" Flooding "<<rxTag.GetValue ()<<" "<<addri<<" Retransmitted Packet "<<packet->GetUid());
      v.push_back(rxTag.GetValue ());
      map_nodes[receiver]=v;
    }  
  Vector scePos;
  Ipv4InterfaceContainer::Iterator i;
  for (i = interfaces.Begin (); i != interfaces.End (); ++i)
    {
      std::pair<Ptr<Ipv4>, uint32_t> pair = *i;
      if ((pair.first)->GetInterfaceForAddress (sender) != -1)
        {  
          Ptr<Node> senderNode = (pair.first)->GetObject<Node> ();
          scePos= GetPosition(senderNode);
          break;
        }
    }
  
  double distance= CalculateDistance(scePos,receiverPos);
  map_distance[distance]=map_distance[distance]+1 ;
  
  receivedApp+=1;
}
Vector 
Flooding::GetPosition(Ptr<Node> node) 
{
  Ptr<MobilityModel> mobility = node->GetObject<MobilityModel>();
  NS_ASSERT (mobility != 0);
  Vector pos = mobility->GetPosition();
  return pos;
}

void
Flooding::WifiPhyRxEndTrace(std::string context, Ptr<const Packet> p) 
{
  packetReceived+=1;
}
void
Flooding::WifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p) 
{
  txPackets+=1;
}
