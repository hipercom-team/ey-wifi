/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2008 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <Hana.Baccouch@inria.fr>
 */
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/ey-wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/olsr-module.h"
#include "ns3/flow-monitor-module.h"
#include <iomanip>
using namespace ns3;
NS_LOG_COMPONENT_DEFINE ("WifiUnicastExample");
class WifiUnicast 
{
public:
  uint32_t receivedApp;
  uint32_t sentApp;
  std::map<double ,uint32_t> map_distance; 
  WifiUnicast();
  /// Configure script parameters, \return true on successful configuration
  bool Configure(int argc, char **argv);
  /// Run simulation
  void Run();
  void GetStatistics(void);
  
private:
  ///\name parameters
  //\{
  /// Number of nodes
  uint32_t size;
  /// Distance between nodes, meters
  double step;
  /// Simulation time, seconds
  double totalTime; //MilliSeconds
  /// Scheduler timer
  Timer m_timer;
  int port; 
  uint32_t packetSize; // = 1000; // bytes
  uint32_t numPackets; // = 50 000 packtes
  double interval; //  µSeconds
  int txPackets;
  int packetReceived;
  Ipv4Address destination;
  //\}
  
  ///\name network
  //\{
  NodeContainer nodes;
  NetDeviceContainer devices;
  Ipv4InterfaceContainer interfaces;
  //\}
  
private:
  void CreateNodes();
  void CreateDevices();
  void InstallInternetStack();
  void InstallApplications();
  static void GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                              uint32_t pktCount, Time pktInterval);
  void ReceivePacket(Ptr<Socket> socket);
  void WifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p); 
  void WifiMacTxBeginTrace(std::string context, Ptr<const Packet> p);	
  void WifiPhyRxDrop(std::string context,
                       Ptr<const Packet> p);
  void WifiPhyRxEndTrace(std::string context, Ptr<const Packet> p) ;
  Vector GetPosition(Ptr<Node> node) ;
};
int
main(int argc, char **argv) 
{ 
  WifiUnicast test;
  if (!test.Configure(argc, argv))
    NS_FATAL_ERROR("Configuration failed. Aborted.");
  test.Run();
  test.GetStatistics();
  return 0;
}

WifiUnicast::WifiUnicast() :
  size(100),
  step(5),
  totalTime(10),
  m_timer(Timer::CANCEL_ON_DESTROY),
  port(80),
  packetSize(1000), 
  numPackets(50000),
  interval(1000)
{
  txPackets=0;
  packetReceived=0;
  receivedApp=0;
  sentApp=0;
  destination=Ipv4Address("255.255.255.255");
}
void
WifiUnicast::GetStatistics(void)
{
  float load= (size*1000/interval)*packetSize/8 ;
  load=load/(6*1024*1024);
  std::cout<<interval <<" "<<load<< " " <<step<<" "<< std::setprecision(4) << size/float(step *10*10*step)<<" "
  << packetReceived<<" "<<(packetReceived/totalTime)/size<< " " 
  << txPackets <<" "
  <<packetReceived/float(txPackets) <<"\n";
}
bool 
WifiUnicast::Configure(int argc, char **argv) 
{
  SeedManager::SetSeed(12345);
  CommandLine cmd;
  cmd.AddValue("size", "Number of nodes.", size);
  cmd.AddValue("time", "Simulation time, s.", totalTime);
  cmd.AddValue("step", "Grid step, m", step);
  cmd.AddValue ("packetSize", "size of application packet sent", packetSize);
  cmd.AddValue ("numPackets", "number of packets generated", numPackets);
  cmd.AddValue ("interval", "interval (MilliSeconds) between packets", interval);
  cmd.Parse(argc, argv);
  return true;
}

void
WifiUnicast::Run() 
{  
  Config::SetDefault("ns3::WifiRemoteStationManager::MaxSlrc",
                     UintegerValue(10));
  CreateNodes();
  CreateDevices();
  InstallInternetStack();
  InstallApplications(); 
  Simulator::Stop(Seconds(totalTime));
  Simulator::Run();
  Simulator::Destroy();
}
void
WifiUnicast::CreateNodes() 
{ 
  nodes.Create(size);
  // Create static grid
  MobilityHelper mobility;
  mobility.SetPositionAllocator("ns3::GridPositionAllocator", "MinX",
                                DoubleValue(0.0), "MinY", DoubleValue(0.0), "DeltaX",
                                DoubleValue(step), "DeltaY", DoubleValue(step), "GridWidth",
                                UintegerValue(10), "LayoutType", StringValue("RowFirst"));
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(nodes);
  for (uint32_t i = 0; i < size; ++i) 
    {
      Ptr<MobilityModel> mobility =
        (nodes.Get(i))->GetObject<MobilityModel>();
      Vector pos = mobility->GetPosition();
      (void) pos;
    }
}
void
WifiUnicast::CreateDevices() 
{ 
  EyNqosWifiMacHelper wifiMac = EyNqosWifiMacHelper::Default();
  wifiMac.SetType("ns3::EyAdhocWifiMac");
  EyYansWifiPhyHelper wifiPhy;
  wifiPhy.SetErrorRateModel("ns3::EyYansErrorRateModel");
  EyYansWifiChannelHelper wifiChannel = EyYansWifiChannelHelper::Default();
  wifiPhy.SetChannel(wifiChannel.Create());
  EyWifiHelper wifi = EyWifiHelper::Default();
  wifi.SetRemoteStationManager("ns3::EyConstantRateWifiManager","DataMode", StringValue ("OfdmRate6Mbps"),  "BurstMode", BooleanValue(false));
  devices = wifi.Install(wifiPhy, wifiMac, nodes);
  
  //PhyTxBegin
  std::ostringstream pathTxBegin;
  pathTxBegin<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyTxBegin";	
  Config::Connect(pathTxBegin.str(),
                  MakeCallback(&WifiUnicast::WifiPhyTxBeginTrace,this));
  //PhyRXEnd                
  std::ostringstream pathPhyRxEnd;
  pathPhyRxEnd<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyRxEnd";         
  Config::Connect(pathPhyRxEnd.str(),
                  MakeCallback(&WifiUnicast::WifiPhyRxEndTrace,this));
}
void
WifiUnicast::InstallInternetStack() 
{
  InternetStackHelper stack;
  stack.Install(nodes);
  Ipv4AddressHelper address;
  address.SetBase("10.0.0.0", "255.0.0.0");
  interfaces = address.Assign(devices);
}

void 
WifiUnicast::InstallApplications() 
{
  TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
  //Reception
  for (int i = 0; i < int(size); i++) 
    {
      Ptr<Socket> recvSink = Socket::CreateSocket(nodes.Get(i), tid);
      InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(),
                                                  port);
      recvSink->Bind(local);
      recvSink->SetRecvCallback(MakeCallback(&WifiUnicast::ReceivePacket, this));
    }
  
  ExponentialVariable x(1000,1500);
  ExponentialVariable distInterval(interval,(interval*4)); //(mean, max value)
  //Transmission
  for (int i = 0; i < 30; i++) 
    {
      Ptr<Ipv4> ipv4;
      ipv4 = (nodes.Get(int(size-i-1)))->GetObject<Ipv4>();
      Ipv4InterfaceAddress addr = ipv4->GetAddress (1,0);
      Ipv4Address dest = addr.GetLocal (); 
      InetSocketAddress remote = InetSocketAddress(
                                                   dest, port);
      Ptr<Socket> source = Socket::CreateSocket(nodes.Get(i), tid);
      source->Connect(remote);
      source->SetAllowBroadcast(false);
      int txBegin = x.GetValue();
      int pktInterval=distInterval.GetValue();
      Simulator::Schedule(MilliSeconds(txBegin), &GenerateTraffic, 
                          source, packetSize, numPackets, MilliSeconds(pktInterval));     
    }
}
void
WifiUnicast::GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                             uint32_t pktCount, Time pktInterval) 
{
  if (pktCount > 0) 
    {
      Ptr<Packet> p =Create<Packet>(pktSize);
      socket->Send(p);
      Simulator::Schedule(pktInterval, &GenerateTraffic, socket, pktSize,
                          pktCount - 1, pktInterval);
      Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
      Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
      Ipv4Address addri = iaddr.GetLocal();
      NS_LOG_UNCOND (Simulator::Now().GetNanoSeconds()<<" "<<addri<< " Packet sent " <<p->GetUid()); 
    }
  else
    {
      socket->Close();
    }
}
void 
WifiUnicast::ReceivePacket(Ptr<Socket> socket) 
{
  Address sourceAddress;
  Ptr<Packet> p = socket->RecvFrom(sourceAddress);
  InetSocketAddress inetSourceAddr = InetSocketAddress::ConvertFrom(
                                                                    sourceAddress);
  Ipv4Address sender = inetSourceAddr.GetIpv4();
  Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
  Ptr<Node> receiver= ipv4->GetObject<Node> ();
  Vector receiverPos= GetPosition(receiver);
  Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
  Ipv4Address addri = iaddr.GetLocal();
  NS_LOG_UNCOND (Simulator::Now().GetNanoSeconds()<<" "<<addri<<" Packet received from " <<sender<<" "<<p->GetUid());
  receivedApp+=1;
  Vector scePos;
  Ipv4InterfaceContainer::Iterator i;
  for (i = interfaces.Begin (); i != interfaces.End (); ++i)
    {
      std::pair<Ptr<Ipv4>, uint32_t> pair = *i;
      //    method (pair.first, pair.second); 
      if ((pair.first)->GetInterfaceForAddress (sender) != -1)
        {  
          Ptr<Node> senderNode = (pair.first)->GetObject<Node> ();
          scePos= GetPosition(senderNode);
          //std::cout<<scePos<<"\n";
          break;
        }
    }
  double distance= CalculateDistance(scePos,receiverPos);
  map_distance[distance]=map_distance[distance]+1 ;
}
Vector 
WifiUnicast::GetPosition(Ptr<Node> node) 
{
  Ptr<MobilityModel> mobility = node->GetObject<MobilityModel>();
  NS_ASSERT (mobility != 0);
  Vector pos = mobility->GetPosition();
  return pos;
}
void
WifiUnicast::WifiPhyRxEndTrace(std::string context, Ptr<const Packet> p) 
{
  packetReceived+=1;
}
void
WifiUnicast::WifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p) 
{
  txPackets+=1;
}
