/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Hana Baccouch <hana.baccouch@inria.fr>
 */

#ifndef EY_MANAGER_H
#define EY_MANAGER_H

#include "ey-dcf-manager.h"
#include "ns3/nstime.h"
#include "ns3/event-id.h"
#include "ey-dca-txop.h"
#include <vector>

namespace ns3 {

class EyWifiPhy;
class EyWifiMac;
class EyMacLow;
class EyPhyListener;
class EyLowDcfListener;
class EyDcfState ;
class EyDcfManager;

/**
 * \brief keep track of the state needed for a single DCF
 * function.
 * \ingroup wifi
 *
 * Multiple instances of a DcfState can be registered in a single
 * DcfManager to implement 802.11e-style relative QoS.
 * DcfState::SetAifsn and DcfState::SetCwBounds allow the user to
 * control the relative QoS differentiation.
 */
class EyState : public EyDcfState
{
public:
  EyState (EyDcaTxop * txop);
  virtual ~EyState ( );
  
  void StartBurstNow (uint32_t nSlots);
  uint32_t GetBurstSlots (void) const;
  Time GetBurstStart (void) const;
  
private:
friend class EyDcfManager;
  /**
   * Called by DcfManager to notify a DcfState subclass
   * that access to the medium is granted and can
   * start immediately.
   */
  virtual void DoNotifyAccessGranted (void) ;
  /**
   * Called by DcfManager to notify a DcfState subclass
   * that an 'internal' collision occured, that is, that
   * the backoff timer of a higher priority DcfState expired
   * at the same time and that access was granted to this
   * higher priority DcfState.
   *
   * The subclass is expected to start a new backoff by
   * calling DcfState::StartBackoffNow and DcfManager::RequestAccess
   * is access is still needed.
   */
  virtual void DoNotifyInternalCollision (void);
  /**
   * Called by DcfManager to notify a DcfState subclass
   * that a normal collision occured, that is, that
   * the medium was busy when access was requested.
   *
   * The subclass is expected to start a new backoff by
   * calling DcfState::StartBackoffNow and DcfManager::RequestAccess
   * is access is still needed.
   */
  virtual void DoNotifyCollision (void);
  /**
  * Called by DcfManager to notify a DcfState subclass
  * that a channel switching occured.
  *
  * The subclass is expected to flush the queue of
  * packets.
  */
  virtual void DoNotifyChannelSwitching () ;

  EyDcaTxop * m_txop ;
  uint32_t m_burstSlots;
};

} // namespace ns3
#endif /* EY_MANAGER_H */
