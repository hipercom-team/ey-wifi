/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Federico Maguolo <maguolof@dei.unipd.it>
 */
#ifndef AARFCD_WIFI_MANAGER_H
#define AARFCD_WIFI_MANAGER_H

#include "ey-wifi-remote-station-manager.h"

namespace ns3 {

struct EyAarfcdWifiRemoteStation;

/**
 * \brief an implementation of the AARF-CD algorithm
 * \ingroup wifi
 *
 * This algorithm was first described in "Efficient Collision Detection for Auto Rate Fallback Algorithm".
 * The implementation available here was done by Federico Maguolo for a very early development
 * version of ns-3. Federico died before merging this work in ns-3 itself so his code was ported
 * to ns-3 later without his supervision.
 */
class EyAarfcdWifiManager : public EyWifiRemoteStationManager
{
public:
  static TypeId GetTypeId (void);
  EyAarfcdWifiManager ();
  virtual ~EyAarfcdWifiManager ();

private:
  // overriden from base class
  virtual EyWifiRemoteStation * DoCreateStation (void) const;
  virtual void DoReportRxOk (EyWifiRemoteStation *station,
                             double rxSnr, EyWifiMode txMode);
  virtual void DoReportRtsFailed (EyWifiRemoteStation *station);
  virtual void DoReportDataFailed (EyWifiRemoteStation *station);
  virtual void DoReportRtsOk (EyWifiRemoteStation *station,
                              double ctsSnr, EyWifiMode ctsMode, double rtsSnr);
  virtual void DoReportDataOk (EyWifiRemoteStation *station,
                               double ackSnr, EyWifiMode ackMode, double dataSnr);
  virtual void DoReportFinalRtsFailed (EyWifiRemoteStation *station);
  virtual void DoReportFinalDataFailed (EyWifiRemoteStation *station);
  virtual EyWifiMode DoGetDataMode (EyWifiRemoteStation *station, uint32_t size);
  virtual EyWifiMode DoGetRtsMode (EyWifiRemoteStation *station);
  virtual bool DoNeedRts (EyWifiRemoteStation *station,
                          Ptr<const Packet> packet, bool normally);
  virtual bool IsLowLatency (void) const;

  void CheckRts (EyAarfcdWifiRemoteStation *station);
  void IncreaseRtsWnd (EyAarfcdWifiRemoteStation *station);
  void ResetRtsWnd (EyAarfcdWifiRemoteStation *station);
  void TurnOffRts (EyAarfcdWifiRemoteStation *station);
  void TurnOnRts (EyAarfcdWifiRemoteStation *station);

  // aarf fields below
  uint32_t m_minTimerThreshold;
  uint32_t m_minSuccessThreshold;
  double m_successK;
  uint32_t m_maxSuccessThreshold;
  double m_timerK;

  // aarf-cd fields below
  uint32_t m_minRtsWnd;
  uint32_t m_maxRtsWnd;
  bool m_rtsFailsAsDataFails;
  bool m_turnOffRtsAfterRateDecrease;
  bool m_turnOnRtsAfterRateIncrease;
};

} // namespace ns3

#endif /* AARFCD_WIFI_MANAGER_H */
