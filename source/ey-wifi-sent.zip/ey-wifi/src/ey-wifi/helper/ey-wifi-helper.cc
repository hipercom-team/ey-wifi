/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2008 INRIA
 * Copyright (c) 2009 MIRKO BANCHI
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 * Author: Mirko Banchi <mk.banchi@gmail.com>
 */
#include "ey-wifi-helper.h"
#include "ns3/ey-wifi-net-device.h"
#include "ns3/ey-wifi-mac.h"
#include "ns3/ey-regular-wifi-mac.h"
#include "ns3/ey-dca-txop.h"
#include "ns3/ey-edca-txop-n.h"
#include "ns3/ey-minstrel-wifi-manager.h"
#include "ns3/ey-wifi-phy.h"
#include "ns3/ey-wifi-remote-station-manager.h"
#include "ns3/ey-wifi-channel.h"
#include "ns3/ey-yans-wifi-channel.h"
#include "ns3/propagation-delay-model.h"
#include "ns3/propagation-loss-model.h"
#include "ns3/mobility-model.h"
#include "ns3/log.h"
#include "ns3/config.h"
#include "ns3/pointer.h"
#include "ns3/simulator.h"
#include "ns3/names.h"

NS_LOG_COMPONENT_DEFINE ("EyWifiHelper");

namespace ns3 {

EyWifiPhyHelper::~EyWifiPhyHelper ()
{
}

EyWifiMacHelper::~EyWifiMacHelper ()
{
}

EyWifiHelper::EyWifiHelper ()
  : m_standard (WIFI_PHY_STANDARD_80211a)
{
}

EyWifiHelper
EyWifiHelper::Default (void)
{
  EyWifiHelper helper;
  helper.SetRemoteStationManager ("ns3::EyArfWifiManager");
  return helper;
}

void
EyWifiHelper::SetRemoteStationManager (std::string type,
                                     std::string n0, const AttributeValue &v0,
                                     std::string n1, const AttributeValue &v1,
                                     std::string n2, const AttributeValue &v2,
                                     std::string n3, const AttributeValue &v3,
                                     std::string n4, const AttributeValue &v4,
                                     std::string n5, const AttributeValue &v5,
                                     std::string n6, const AttributeValue &v6,
                                     std::string n7, const AttributeValue &v7)
{
  m_stationManager = ObjectFactory ();
  m_stationManager.SetTypeId (type);
  m_stationManager.Set (n0, v0);
  m_stationManager.Set (n1, v1);
  m_stationManager.Set (n2, v2);
  m_stationManager.Set (n3, v3);
  m_stationManager.Set (n4, v4);
  m_stationManager.Set (n5, v5);
  m_stationManager.Set (n6, v6);
  m_stationManager.Set (n7, v7);
}

void
EyWifiHelper::SetStandard (enum EyWifiPhyStandard standard)
{
  m_standard = standard;
}

NetDeviceContainer
EyWifiHelper::Install (const EyWifiPhyHelper &phyHelper,
                     const EyWifiMacHelper &macHelper, NodeContainer c) const
{
  NetDeviceContainer devices;
  for (NodeContainer::Iterator i = c.Begin (); i != c.End (); ++i)
    {
      Ptr<Node> node = *i;
      Ptr<EyWifiNetDevice> device = CreateObject<EyWifiNetDevice> ();
      Ptr<EyWifiRemoteStationManager> manager = m_stationManager.Create<EyWifiRemoteStationManager> ();
      Ptr<EyWifiMac> mac = macHelper.Create ();
      Ptr<EyWifiPhy> phy = phyHelper.Create (node, device);
      mac->SetAddress (Mac48Address::Allocate ());
      mac->ConfigureStandard (m_standard);
      phy->ConfigureStandard (m_standard);
      device->SetMac (mac);
      device->SetPhy (phy);
      device->SetRemoteStationManager (manager);
      node->AddDevice (device);
      devices.Add (device);
      NS_LOG_DEBUG ("node=" << node << ", mob=" << node->GetObject<MobilityModel> ());
    }
  return devices;
}

NetDeviceContainer
EyWifiHelper::Install (const EyWifiPhyHelper &phy,
                     const EyWifiMacHelper &mac, Ptr<Node> node) const
{
  return Install (phy, mac, NodeContainer (node));
}

NetDeviceContainer
EyWifiHelper::Install (const EyWifiPhyHelper &phy,
                     const EyWifiMacHelper &mac, std::string nodeName) const
{
  Ptr<Node> node = Names::Find<Node> (nodeName);
  return Install (phy, mac, NodeContainer (node));
}

void
EyWifiHelper::EnableLogComponents (void)
{
  LogComponentEnable ("EyAarfcd", LOG_LEVEL_ALL);
  LogComponentEnable ("EyAdhocWifiMac", LOG_LEVEL_ALL);
  LogComponentEnable ("EyAmrrWifiRemoteStation", LOG_LEVEL_ALL);
  LogComponentEnable ("EyApWifiMac", LOG_LEVEL_ALL);
  LogComponentEnable ("ns3::EyArfWifiManager", LOG_LEVEL_ALL);
  LogComponentEnable ("EyCara", LOG_LEVEL_ALL);
  LogComponentEnable ("EyDcaTxop", LOG_LEVEL_ALL);
  LogComponentEnable ("EyDcfManager", LOG_LEVEL_ALL);
  LogComponentEnable ("EyDsssErrorRateModel", LOG_LEVEL_ALL);
  LogComponentEnable ("EyEdcaTxopN", LOG_LEVEL_ALL);
  LogComponentEnable ("EyInterferenceHelper", LOG_LEVEL_ALL);
  LogComponentEnable ("EyJakes", LOG_LEVEL_ALL);
  LogComponentEnable ("EyMacLow", LOG_LEVEL_ALL);
  LogComponentEnable ("EyMacRxMiddle", LOG_LEVEL_ALL);
  LogComponentEnable ("EyMsduAggregator", LOG_LEVEL_ALL);
  LogComponentEnable ("EyMsduStandardAggregator", LOG_LEVEL_ALL);
  LogComponentEnable ("EyNistErrorRateModel", LOG_LEVEL_ALL);
  LogComponentEnable ("EyOnoeWifiRemoteStation", LOG_LEVEL_ALL);
  LogComponentEnable ("EyPropagationLossModel", LOG_LEVEL_ALL);
  LogComponentEnable ("EyRegularWifiMac", LOG_LEVEL_ALL);
  LogComponentEnable ("EyRraaWifiManager", LOG_LEVEL_ALL);
  LogComponentEnable ("EyStaWifiMac", LOG_LEVEL_ALL);
  LogComponentEnable ("EySupportedRates", LOG_LEVEL_ALL);
  LogComponentEnable ("EyWifiChannel", LOG_LEVEL_ALL);
  LogComponentEnable ("EyWifiPhyStateHelper", LOG_LEVEL_ALL);
  LogComponentEnable ("EyWifiPhy", LOG_LEVEL_ALL);
  LogComponentEnable ("EyWifiRemoteStationManager", LOG_LEVEL_ALL);
  LogComponentEnable ("EyYansErrorRateModel", LOG_LEVEL_ALL);
  LogComponentEnable ("EyYansWifiChannel", LOG_LEVEL_ALL);
  LogComponentEnable ("EyYansWifiPhy", LOG_LEVEL_ALL);
}

int64_t
EyWifiHelper::AssignStreams (NetDeviceContainer c, int64_t stream)
{
  int64_t currentStream = stream;
  Ptr<NetDevice> netDevice;
  for (NetDeviceContainer::Iterator i = c.Begin (); i != c.End (); ++i)
    {
      netDevice = (*i);
      Ptr<EyWifiNetDevice> wifi = DynamicCast<EyWifiNetDevice> (netDevice);
      if (wifi)
        {
          // Handle any random numbers in the PHY objects.
          currentStream += wifi->GetPhy ()->AssignStreams (currentStream);

          // Handle any random numbers in the station managers.
          Ptr<EyWifiRemoteStationManager> manager = wifi->GetRemoteStationManager ();
          Ptr<EyMinstrelWifiManager> minstrel = DynamicCast<EyMinstrelWifiManager> (manager);
          if (minstrel)
            {
              currentStream += minstrel->AssignStreams (currentStream);
            }

          // Handle any random numbers in the MAC objects.
          Ptr<EyWifiMac> mac = wifi->GetMac ();
          Ptr<EyRegularWifiMac> rmac = DynamicCast<EyRegularWifiMac> (mac);
          if (rmac)
            {
              PointerValue ptr;
              rmac->GetAttribute ("EyDcaTxop", ptr);
              Ptr<EyDcaTxop> dcaTxop = ptr.Get<EyDcaTxop> ();
              currentStream += dcaTxop->AssignStreams (currentStream);

              rmac->GetAttribute ("VO_EdcaTxopN", ptr);
              Ptr<EyEdcaTxopN> vo_edcaTxopN = ptr.Get<EyEdcaTxopN> ();
              currentStream += vo_edcaTxopN->AssignStreams (currentStream);

              rmac->GetAttribute ("VI_EdcaTxopN", ptr);
              Ptr<EyEdcaTxopN> vi_edcaTxopN = ptr.Get<EyEdcaTxopN> ();
              currentStream += vi_edcaTxopN->AssignStreams (currentStream);

              rmac->GetAttribute ("BE_EdcaTxopN", ptr);
              Ptr<EyEdcaTxopN> be_edcaTxopN = ptr.Get<EyEdcaTxopN> ();
              currentStream += be_edcaTxopN->AssignStreams (currentStream);

              rmac->GetAttribute ("BK_EdcaTxopN", ptr);
              Ptr<EyEdcaTxopN> bk_edcaTxopN = ptr.Get<EyEdcaTxopN> ();
              currentStream += bk_edcaTxopN->AssignStreams (currentStream);
            }
        }
    }
  return (currentStream - stream);
}

} // namespace ns3
