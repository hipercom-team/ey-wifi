/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006 INRIA
 *               2010      NICTA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 *         Quincy Tse <quincy.tse@nicta.com.au> (Case for Bug 991)
 */

#include "ns3/ey-wifi-net-device.h"
#include "ns3/ey-yans-wifi-channel.h"
#include "ns3/ey-adhoc-wifi-mac.h"
#include "ns3/ey-yans-wifi-phy.h"
#include "ns3/ey-arf-wifi-manager.h"
#include "ns3/propagation-delay-model.h"
#include "ns3/propagation-loss-model.h"
#include "ns3/ey-error-rate-model.h"
#include "ns3/ey-yans-error-rate-model.h"
#include "ns3/constant-position-mobility-model.h"
#include "ns3/node.h"
#include "ns3/simulator.h"
#include "ns3/test.h"
#include "ns3/object-factory.h"
#include "ns3/dca-txop.h"
#include "ns3/mac-rx-middle.h"
#include "ns3/pointer.h"
#include "ns3/rng-seed-manager.h"

namespace ns3 {

class EyWifiTest : public TestCase
{
public:
  EyWifiTest ();

  virtual void DoRun (void);
private:
  void RunOne (void);
  void CreateOne (Vector pos, Ptr<EyYansWifiChannel> channel);
  void SendOnePacket (Ptr<EyWifiNetDevice> dev);

  ObjectFactory m_manager;
  ObjectFactory m_mac;
  ObjectFactory m_propDelay;
};

EyWifiTest::EyWifiTest ()
  : TestCase ("EyWifi")
{
}

void
EyWifiTest::SendOnePacket (Ptr<EyWifiNetDevice> dev)
{
  Ptr<Packet> p = Create<Packet> ();
  dev->Send (p, dev->GetBroadcast (), 1);
}

void
EyWifiTest::CreateOne (Vector pos, Ptr<EyYansWifiChannel> channel)
{
  Ptr<Node> node = CreateObject<Node> ();
  Ptr<EyWifiNetDevice> dev = CreateObject<EyWifiNetDevice> ();

  Ptr<EyWifiMac> mac = m_mac.Create<EyWifiMac> ();
  mac->ConfigureStandard (WIFI_PHY_STANDARD_80211a);
  Ptr<ConstantPositionMobilityModel> mobility = CreateObject<ConstantPositionMobilityModel> ();
  Ptr<EyYansWifiPhy> phy = CreateObject<EyYansWifiPhy> ();
  Ptr<EyErrorRateModel> error = CreateObject<EyYansErrorRateModel> ();
  phy->SetErrorRateModel (error);
  phy->SetChannel (channel);
  phy->SetDevice (dev);
  phy->SetMobility (node);
  phy->ConfigureStandard (WIFI_PHY_STANDARD_80211a);
  Ptr<EyWifiRemoteStationManager> manager = m_manager.Create<EyWifiRemoteStationManager> ();

  mobility->SetPosition (pos);
  node->AggregateObject (mobility);
  mac->SetAddress (Mac48Address::Allocate ());
  dev->SetMac (mac);
  dev->SetPhy (phy);
  dev->SetRemoteStationManager (manager);
  node->AddDevice (dev);

  Simulator::Schedule (Seconds (1.0), &EyWifiTest::SendOnePacket, this, dev);
}

void
EyWifiTest::RunOne (void)
{
  Ptr<EyYansWifiChannel> channel = CreateObject<EyYansWifiChannel> ();
  Ptr<PropagationDelayModel> propDelay = m_propDelay.Create<PropagationDelayModel> ();
  Ptr<PropagationLossModel> propLoss = CreateObject<RandomPropagationLossModel> ();
  channel->SetPropagationDelayModel (propDelay);
  channel->SetPropagationLossModel (propLoss);

  CreateOne (Vector (0.0, 0.0, 0.0), channel);
  CreateOne (Vector (5.0, 0.0, 0.0), channel);
  CreateOne (Vector (5.0, 0.0, 0.0), channel);

  Simulator::Run ();
  Simulator::Destroy ();

  Simulator::Stop (Seconds (10.0));
}

void
EyWifiTest::DoRun (void)
{
  m_mac.SetTypeId ("ns3::EyAdhocWifiMac");
  m_propDelay.SetTypeId ("ns3::ConstantSpeedPropagationDelayModel");
  m_manager.SetTypeId ("ns3::EyConstantRateWifiManager");
  RunOne ();
  
  Simulator::Destroy ();
}
}
