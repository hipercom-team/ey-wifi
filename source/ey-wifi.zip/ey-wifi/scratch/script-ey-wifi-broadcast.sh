#!/bin/sh
INTERVAL="1000 700 500 300 200 150 130 110 100 70 50 40 30 20 10 5 4 3 2 1"
#INTERVAL="1000 500 300 200 150 100 40 20 10 5 4 1"
plotEyWifi=""
plotWifi=""
eywifi=""
wifi=""

#simulation
for inter in  $INTERVAL
do
    eywifi=$(./waf --run "scratch/ey-wifi-broadcast --interval=$inter")
    plotEyWifi="$plotEyWifi$eywifi\n"
    eywifi=""
    
    wifi=$(./waf --run "scratch/wifi-broadcast --interval=$inter")
    plotWifi="$plotWifi$wifi\n"
    wifi=""
done

echo -e $plotEyWifi > eywifi-results.tr
echo -e $plotWifi > wifi-results.tr

#Plot
gnuplot "scratch/plot-broadcast.gp"
okular broadcast-packets-received.jpeg
