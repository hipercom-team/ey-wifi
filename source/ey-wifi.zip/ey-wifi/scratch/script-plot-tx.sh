for i in  $(seq 0 2)	
do
  ./waf --run "scratch/ey-wifi-plot-tx --nodeId=$i" > "log-node-$i.dat"
done

gnuplot scratch/plot-tx.gp
xdg-open plot-tx.jpeg
xdg-open plot-tx-zoom.jpeg

#okular plot-tx.jpeg
#okular plot-tx-zoom.jpeg
