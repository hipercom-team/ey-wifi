/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2008 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <Hana.Baccouch@inria.fr>
 */
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/ey-wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/log.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("EyWifiBroadcastExample");

class EyWifiBroadcast 
{
public:
  EyWifiBroadcast();
  /// Configure script parameters, \return true on successful configuration
  bool Configure(int argc, char **argv);
  /// Run simulation
  void Run();
  //void GetStatistics(void);
private:
  ///\name parameters
  //\{
  /// Number of nodes
  uint32_t size;
  /// Distance between nodes, meters
  double step;
  /// Simulation time, seconds
  double totalTime; //MilliSeconds
  /// Scheduler timer
  Timer m_timer;
  int port; 
  uint32_t packetSize; // = 1000; // bytes
  uint32_t numPackets; // = 50 000 packtes
  double interval; //  µSeconds
  //\}
  
  ///\name network
  //\{
  NodeContainer nodes;
  NetDeviceContainer devices;
  Ipv4InterfaceContainer interfaces;
  //\}
private:
  void CreateNodes();
  void CreateDevices();
  void InstallInternetStack();
  void InstallApplications();
  static void GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                              uint32_t pktCount, Time pktInterval);
  static void ReceivePacket(Ptr<Socket> socket);
  void EyWifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p);
  void EyWifiPhyTxEndTrace(std::string context, Ptr<const Packet> p) ;
  void EyWifiBurstBeginTrace(std::string context, uint32_t slots);
  void EyWifiBurstEndTrace(std::string context, uint32_t slots);
};
int
main(int argc, char **argv) 
{
  
  EyWifiBroadcast test;
  if (!test.Configure(argc, argv))
    NS_FATAL_ERROR("Configuration failed. Aborted.");
  
  test.Run();
  return 0;
}

//-----------------------------------------------------------------------------
EyWifiBroadcast::EyWifiBroadcast() :
  size(50),
  step(20),
  totalTime(1),
  m_timer(Timer::CANCEL_ON_DESTROY),
  port(80),
  packetSize(1000), 
  numPackets(50000),
  interval(1000)
{
}
bool 
EyWifiBroadcast::Configure(int argc, char **argv) 
{
  SeedManager::SetSeed(12345);
  CommandLine cmd;
  cmd.AddValue("size", "Number of nodes.", size);
  cmd.AddValue("time", "Simulation time, s.", totalTime);
  cmd.AddValue("step", "Grid step, m", step);
  cmd.AddValue ("packetSize", "size of application packet sent", packetSize);
  cmd.AddValue ("numPackets", "number of packets generated", numPackets);
  cmd.AddValue ("interval", "interval (MilliSeconds) between packets", interval);
  cmd.Parse(argc, argv);
  return true;
}
void
EyWifiBroadcast::Run() 
{  
  Config::SetDefault("ns3::EyWifiRemoteStationManager::MaxSlrc",
                     UintegerValue(10));
  CreateNodes();
  CreateDevices();
  InstallInternetStack();
  InstallApplications();
  Simulator::Stop(Seconds(totalTime));
  Simulator::Run();
  Simulator::Destroy();
}
void
EyWifiBroadcast::CreateNodes() 
{ 
  nodes.Create(size);
  
  // Create static grid
  MobilityHelper mobility;
  mobility.SetPositionAllocator("ns3::GridPositionAllocator", "MinX",
                                DoubleValue(0.0), "MinY", DoubleValue(0.0), "DeltaX",
                                DoubleValue(step), "DeltaY", DoubleValue(step), "GridWidth",
                                UintegerValue(5), "LayoutType", StringValue("RowFirst"));
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  
  mobility.Install(nodes);

  // Name nodes
  for (uint32_t i = 0; i < size; ++i) 
    {
      Ptr<MobilityModel> mobility =
        (nodes.Get(i))->GetObject<MobilityModel>();
      Vector pos = mobility->GetPosition();
      (void) pos;
    }
}
void
EyWifiBroadcast::CreateDevices() 
{ 
  EyNqosWifiMacHelper wifiMac = EyNqosWifiMacHelper::Default();
  wifiMac.SetType("ns3::EyAdhocWifiMac");
  EyYansWifiPhyHelper wifiPhy;
  wifiPhy.SetErrorRateModel("ns3::EyYansErrorRateModel");
  
  EyYansWifiChannelHelper wifiChannel = EyYansWifiChannelHelper::Default();
  wifiPhy.SetChannel(wifiChannel.Create());
  
  EyWifiHelper wifi = EyWifiHelper::Default();
  wifi.SetRemoteStationManager("ns3::EyConstantRateWifiManager","DataMode", StringValue ("OfdmRate6Mbps"),  "BurstMode", BooleanValue(true));
  devices = wifi.Install(wifiPhy, wifiMac, nodes);
  
  std::ostringstream pathTxBegin;
  pathTxBegin<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyTxBegin";	
  Config::Connect(pathTxBegin.str(),
                  MakeCallback(&EyWifiBroadcast::EyWifiPhyTxBeginTrace,this));
  
  std::ostringstream pathTxEnd;
  pathTxEnd<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyTxEnd";		
  Config::Connect(pathTxEnd.str(),
                  MakeCallback(&EyWifiBroadcast::EyWifiPhyTxEndTrace,this));
                     
  std::ostringstream pathBurstBegin;
  pathBurstBegin<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/BurstTxBegin";	
  Config::Connect(
                  pathBurstBegin.str(),
                  MakeCallback(&EyWifiBroadcast::EyWifiBurstBeginTrace, this));        
  std::ostringstream pathBurstEnd;
  pathBurstEnd<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/BurstTxEnd";	
  Config::Connect(pathBurstEnd.str(),
                  MakeCallback (&EyWifiBroadcast::EyWifiBurstEndTrace, this));
  
}
void
EyWifiBroadcast::InstallInternetStack() 
{
  InternetStackHelper stack;
  stack.Install(nodes);
  Ipv4AddressHelper address;
  address.SetBase("10.0.0.0", "255.0.0.0");
  interfaces = address.Assign(devices);
}
void 
EyWifiBroadcast::InstallApplications() 
{
  TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
  
  //Reception
  for (int i = 0; i < int(size); i++) 
    {
      Ptr<Socket> recvSink = Socket::CreateSocket(nodes.Get(i), tid);
      InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(),
                                                  port);
      recvSink->Bind(local);
      recvSink->SetRecvCallback(MakeCallback(&ReceivePacket));
    }
  
   ExponentialVariable x(1000,1500);
   ExponentialVariable distInterval(interval,(interval*4)); //(mean, max value)
   
   //Transmission
  for (int i = 0; i < int(size); i++) 
    {
      Ptr<Socket> source = Socket::CreateSocket(nodes.Get(i), tid);
      InetSocketAddress remote = InetSocketAddress(
                                                   Ipv4Address("255.255.255.255"), port);
      source->Connect(remote);
      source->SetAllowBroadcast(true);
      
      int txBegin = x.GetValue();
      int pktInterval=distInterval.GetValue();
      //std::cout<<"\ntxbegin"<<txBegin;
      Simulator::Schedule(MilliSeconds(txBegin), &GenerateTraffic, 
                          source, packetSize, numPackets, MilliSeconds(pktInterval));
      
    }
}
void
EyWifiBroadcast::GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                                 uint32_t pktCount, Time pktInterval) 
{
  if (pktCount > 0) 
    {
      socket->Send(Create<Packet>(pktSize));
      Simulator::Schedule(pktInterval, &GenerateTraffic, socket, pktSize,
                          pktCount - 1, pktInterval);
      Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
      Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
      Ipv4Address addri = iaddr.GetLocal();
      (void) addri;
      //NS_LOG_UNCOND(Simulator::Now().GetNanoSeconds()<<" ns Node "<<addri<<" broadcasts packet.");
    }
  else
    {
      socket->Close();
    }
}
void 
EyWifiBroadcast::ReceivePacket(Ptr<Socket> socket) 
{
  Address sourceAddress;
  Ptr<Packet> p = socket->RecvFrom(sourceAddress);
  InetSocketAddress inetSourceAddr = InetSocketAddress::ConvertFrom(
                                                                    sourceAddress);
  Ipv4Address sender = inetSourceAddr.GetIpv4();
  Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
  Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
  Ipv4Address addri = iaddr.GetLocal();
  (void) addri;
  (void) sender;
  //NS_LOG_UNCOND(Simulator::Now().GetNanoSeconds()<<" ns Node "<<sender<<" received packet from node "<<addri);
}
void
EyWifiBroadcast::EyWifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p){
  int posNodeId=10;
  int pos=(int)context.find("/",posNodeId);
  int nodeId =atoi ((context.substr(posNodeId,(pos-posNodeId))).c_str()) ;
  NS_LOG_UNCOND ( nodeId<<" "<< Simulator::Now().GetSeconds()<<" PhyTxBegin "<<p->GetUid());
}
void
EyWifiBroadcast::EyWifiPhyTxEndTrace(std::string context, Ptr<const Packet> p) 
{
  int posNodeId=10;
  int pos=(int)context.find("/",posNodeId);
  int nodeId =atoi ((context.substr(posNodeId,(pos-posNodeId))).c_str()) ;
  NS_LOG_UNCOND ( nodeId<<" "<<  Simulator::Now().GetSeconds()<<" PhyTxEnd "<<p->GetUid());
}
void
EyWifiBroadcast::EyWifiBurstBeginTrace(std::string context, uint32_t slots)
{
  int posNodeId=10;
  int pos=(int)context.find("/",posNodeId);
  int nodeId =atoi ((context.substr(posNodeId,(pos-posNodeId))).c_str()) ;
  NS_LOG_UNCOND (nodeId<<" "<<  Simulator::Now().GetSeconds()<<" BurstBegin "<<slots);
}
void
EyWifiBroadcast::EyWifiBurstEndTrace(std::string context, uint32_t slots)
{
  int posNodeId=10;
  int pos=(int)context.find("/",posNodeId);
  int nodeId =atoi ((context.substr(posNodeId,(pos-posNodeId))).c_str()) ;
  NS_LOG_UNCOND ( nodeId<<" "<<  Simulator::Now().GetSeconds()<<" BurstEnd "<<slots);
}
