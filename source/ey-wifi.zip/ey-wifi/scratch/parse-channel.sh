#!/bin/sh
#Bradcast Example, 200 nodes
./waf --run scratch/ey-wifi-broadcast-example 2> "channel-log.dat"

#Parse logs and plot channel
python scratch/EyWifiChannel.py
okular ey-wifi-channel.png
