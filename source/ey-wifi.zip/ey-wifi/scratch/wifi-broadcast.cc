 /* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2008 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <Hana.Baccouch@inria.fr>
 */
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/ey-wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/log.h"

using namespace ns3;
/**
 * \brief Test script.
 * 
 * This example creates 2 dimensional (default 5x5) grid topology and then nodes send periodically broadcast messages.
 * 
 * n20  n21  n22  n23  n24
 * n15  n16  n17  n18  n19
 * n10  n11  n12  n13  n14
 * n5   n6   n7   n8   n9
 * n0   n1   n2   n3   n4
 * 
 * Broadcast packets
 */

NS_LOG_COMPONENT_DEFINE ("WifiBroadcastExample");

class WifiBroadcast 
{
public:
  WifiBroadcast();
  /// Configure script parameters, \return true on successful configuration
  bool Configure(int argc, char **argv);
  /// Run simulation
  void Run();
  void GetStatistics(void);
private:
  ///\name parameters
  //\{
  /// Number of nodes
  uint32_t size;
  /// Distance between nodes, meters
  double step;
  /// Simulation time, seconds
  double totalTime; //MilliSeconds
  /// Scheduler timer
  Timer m_timer;
  int port; 
  uint32_t packetSize; // = 1000; // bytes
  uint32_t numPackets; // = 50 000 packtes
  double interval; //  µSeconds
  int txPackets;
  int packetReceived;
  //\}
  
  ///\name network
  //\{
  NodeContainer nodes;
  NetDeviceContainer devices;
  Ipv4InterfaceContainer interfaces;
  //\}
  
private:
  void CreateNodes();
  void CreateDevices();
  void InstallInternetStack();
  void InstallApplications();
  static void GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                              uint32_t pktCount, Time pktInterval);
  static void ReceivePacket(Ptr<Socket> socket);
  void WifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p);
  void WifiPhyRxEndTrace(std::string context, Ptr<const Packet> p) ;  
};

int
main(int argc, char **argv) 
{
  
  WifiBroadcast test;
  if (!test.Configure(argc, argv))
    NS_FATAL_ERROR("Configuration failed. Aborted.");
  
  test.Run();
  test.GetStatistics();
  return 0;
}

//-----------------------------------------------------------------------------
WifiBroadcast::WifiBroadcast() :
  size(25),
  step(1),
  totalTime(10),
  m_timer(Timer::CANCEL_ON_DESTROY),
  port(80),
  packetSize(1000), 
  numPackets(50000),
  interval(1000)
{
  txPackets=0;
  packetReceived=0;

}

void 
WifiBroadcast::GetStatistics(void)
{
  float load= (size*1000/interval)*packetSize/8 ;
  load=load/(6*1024*1024);
  
  std::cout<<interval <<" "<<load<< " " 
  << packetReceived<<" "<<(packetReceived/totalTime)/size<< " " 
  << txPackets <<" "
  <<packetReceived/float(txPackets) <<"\n";

}

bool 
WifiBroadcast::Configure(int argc, char **argv) 
{
  SeedManager::SetSeed(12345);
  CommandLine cmd;
  cmd.AddValue("size", "Number of nodes.", size);
  cmd.AddValue("time", "Simulation time, s.", totalTime);
  cmd.AddValue("step", "Grid step, m", step);
  cmd.AddValue ("packetSize", "size of application packet sent", packetSize);
  cmd.AddValue ("numPackets", "number of packets generated", numPackets);
  cmd.AddValue ("interval", "interval (MilliSeconds) between packets", interval);
  cmd.Parse(argc, argv);
  return true;
}

void
WifiBroadcast::Run() 
{  
  Config::SetDefault("ns3::EyWifiRemoteStationManager::MaxSlrc",
                     UintegerValue(10));
  CreateNodes();
  CreateDevices();
  InstallInternetStack();
  InstallApplications();
  Simulator::Stop(Seconds(totalTime));
  Simulator::Run();
  Simulator::Destroy();
}

void
WifiBroadcast::CreateNodes() 
{ 
  nodes.Create(size);
  // Create static grid
  MobilityHelper mobility;
  mobility.SetPositionAllocator("ns3::GridPositionAllocator", "MinX",
                                DoubleValue(0.0), "MinY", DoubleValue(0.0), "DeltaX",
                                DoubleValue(step), "DeltaY", DoubleValue(step), "GridWidth",
                                UintegerValue(5), "LayoutType", StringValue("RowFirst"));
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  
  mobility.Install(nodes);

}
void
WifiBroadcast::CreateDevices() 
{ 
  EyNqosWifiMacHelper wifiMac = EyNqosWifiMacHelper::Default();
  wifiMac.SetType("ns3::EyAdhocWifiMac");
  EyYansWifiPhyHelper wifiPhy;
  wifiPhy.SetErrorRateModel("ns3::EyYansErrorRateModel");
  EyYansWifiChannelHelper wifiChannel = EyYansWifiChannelHelper::Default();
  wifiPhy.SetChannel(wifiChannel.Create());
  
  EyWifiHelper wifi = EyWifiHelper::Default();
  wifi.SetRemoteStationManager("ns3::EyConstantRateWifiManager","DataMode", StringValue ("OfdmRate6Mbps"),  "BurstMode", BooleanValue(false));
  devices = wifi.Install(wifiPhy, wifiMac, nodes);
  
  //PhyTxBegin 
  std::ostringstream pathTxBegin;
  pathTxBegin<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyTxBegin";	
  Config::Connect(pathTxBegin.str(),
                  MakeCallback(&WifiBroadcast::WifiPhyTxBeginTrace,this));
  
                                     
  //PhyRXEnd                
  std::ostringstream pathPhyRxEnd;
  pathPhyRxEnd<<"NodeList/*/DeviceList/*/$ns3::EyWifiNetDevice/Phy/PhyRxEnd";           
  Config::Connect(pathPhyRxEnd.str(),
                  MakeCallback(&WifiBroadcast::WifiPhyRxEndTrace,this));

}


void
WifiBroadcast::InstallInternetStack() 
{
  InternetStackHelper stack;
  stack.Install(nodes);
  Ipv4AddressHelper address;
  address.SetBase("10.0.0.0", "255.0.0.0");
  interfaces = address.Assign(devices);
}

void 
WifiBroadcast::InstallApplications() 
{
  TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
  
  //Reception
  for (int i = 0; i < int(size); i++) 
    {
      Ptr<Socket> recvSink = Socket::CreateSocket(nodes.Get(i), tid);
      InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(),
                                                  port);
      recvSink->Bind(local);
      recvSink->SetRecvCallback(MakeCallback(&ReceivePacket));
    }
  
  ExponentialVariable x(1000,1500);
  ExponentialVariable distInterval(interval,(interval*4)); //(mean, max value)
  
  //Transmission
  for (int i = 0; i < int(size); i++) 
    {
      Ptr<Socket> source = Socket::CreateSocket(nodes.Get(i), tid);
      InetSocketAddress remote = InetSocketAddress(
                                                   Ipv4Address("255.255.255.255"), port);
      source->Connect(remote);
      source->SetAllowBroadcast(true);
      
      int txBegin = x.GetValue();
      int pktInterval=distInterval.GetValue();
      //std::cout<<"\ntxbegin"<<txBegin;
      Simulator::Schedule(MilliSeconds(txBegin), &GenerateTraffic, 
                          source, packetSize, numPackets, MilliSeconds(pktInterval));
      
    }
}
void
WifiBroadcast::GenerateTraffic(Ptr<Socket> socket, uint32_t pktSize,
                                 uint32_t pktCount, Time pktInterval) 
{
  if (pktCount > 0) 
    {
      socket->Send(Create<Packet>(pktSize));
      Simulator::Schedule(pktInterval, &GenerateTraffic, socket, pktSize,
                          pktCount - 1, pktInterval);
      Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
      Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
      Ipv4Address addri = iaddr.GetLocal();
      (void) addri;
      //NS_LOG_UNCOND(Simulator::Now().GetNanoSeconds()<<" ns Node "<<addri<<" broadcasts packet.");
    }
  else
    {
      socket->Close();
    }
}
void 
WifiBroadcast::ReceivePacket(Ptr<Socket> socket) 
{
  Address sourceAddress;
  Ptr<Packet> p = socket->RecvFrom(sourceAddress);
  InetSocketAddress inetSourceAddr = InetSocketAddress::ConvertFrom(
                                                                    sourceAddress);
  Ipv4Address sender = inetSourceAddr.GetIpv4();
  (void) sender;
  Ptr<Ipv4> ipv4 = socket->GetNode()->GetObject<Ipv4>();
  Ipv4InterfaceAddress iaddr = ipv4->GetAddress(1, 0);
  Ipv4Address addri = iaddr.GetLocal();
  (void) addri;
  //NS_LOG_UNCOND(Simulator::Now().GetNanoSeconds()<<" ns Node "<<sender<<" received packet from node "<<addri);
}
void
WifiBroadcast::WifiPhyRxEndTrace(std::string context, Ptr<const Packet> p) 
{
  packetReceived+=1;
}
void
WifiBroadcast::WifiPhyTxBeginTrace(std::string context, Ptr<const Packet> p)
{
  txPackets+=1;
}
