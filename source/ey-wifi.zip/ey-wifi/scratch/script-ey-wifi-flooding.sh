#!/bin/sh
INTERVAL="1000 700 300 200 130 110 70 50 20 10 4 3 2 1"
plotEyWifi=""
plotWifi=""
eywifi=""
wifi=""

#Simulation
for inter in  $INTERVAL
do
    eywifi=$(./waf --run "scratch/ey-wifi-flooding --interval=$inter"  2> "ey-wifi-flooding-$inter.dat")
    plotEyWifi="$plotEyWifi$eywifi\n"
    eywifi=""
    wifi=$(./waf --run "scratch/wifi-flooding --interval=$inter"  2> "wifi-flooding-$inter.dat")
    plotWifi="$plotWifi$wifi\n"
    wifi=""
done

echo -e $plotEyWifi > eywifi-flooding-results.tr
echo -e $plotWifi > wifi-flooding-results.tr

STEP="20 17 15 10 7 4 3 2 1"
plotEyWifi=""
plotWifi=""
eywifi=""
wifi=""

#Simulation
for step in  $STEP
do
    eywifi=$(./waf --run "scratch/ey-wifi-flooding --step=$step"  2> "ey-wifi-flooding-density-$inter.dat")
    plotEyWifi="$plotEyWifi$eywifi\n"
    eywifi=""
    
    wifi=$(./waf --run "scratch/wifi-flooding --step=$step"  2> "wifi-flooding-density-$inter.dat")
    plotWifi="$plotWifi$wifi\n"
    wifi=""
done

echo -e $plotEyWifi > eywifi-flooding-density-results.tr
echo -e $plotWifi > wifi-flooding-density-results.tr

#Plot

gnuplot "scratch/plot-flooding.gp"
okular flooding-packets-received.jpeg
okular flooding-density-packets-received.jpeg

