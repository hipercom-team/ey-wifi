/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 * Modifications added by : Hana Baccouch <hana.baccouch@inria.fr>
 */

#include "ns3/assert.h"
#include "ns3/packet.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/node.h"
#include "ns3/uinteger.h"
#include "ns3/pointer.h"


#include "ey-dca-txop.h"
#include "ey-dcf-manager.h"
#include "ey-ey-manager.h"
#include "ey-mac-low.h"
#include "ey-wifi-mac-queue.h"
#include "ey-mac-tx-middle.h"
#include "ey-wifi-mac-trailer.h"
#include "ey-wifi-mac.h"
#include "ey-random-stream.h"
#include "ns3/random-variable.h"
#include "ey-burst-listener.h"

NS_LOG_COMPONENT_DEFINE ("EyDcaTxop");

#undef NS_LOG_APPEND_CONTEXT
#define NS_LOG_APPEND_CONTEXT if (m_low != 0) { std::clog << "[mac=" << m_low->GetAddress () << "] "; }

namespace ns3 {
  
class EyDcaTxop::Dcf : public EyDcfState
{
public:
  Dcf (EyDcaTxop * txop)
    : m_txop (txop)
  {
  }
private:
  virtual void DoNotifyAccessGranted (void)
  {
    m_txop->NotifyAccessGranted ();
  }
  virtual void DoNotifyInternalCollision (void)
  {
    m_txop->NotifyInternalCollision ();
  }
  virtual void DoNotifyCollision (void)
  {
    m_txop->NotifyCollision ();
  }
  virtual void DoNotifyChannelSwitching (void)
  {
    m_txop->NotifyChannelSwitching ();
  }
  EyDcaTxop *m_txop;
};

class EyDcaTxop::TransmissionListener : public EyMacLowTransmissionListener
{
public:
  TransmissionListener (EyDcaTxop * txop)
    : EyMacLowTransmissionListener (),
      m_txop (txop) {
  }

  virtual ~TransmissionListener () {}
  
  virtual void GotCts (double snr, EyWifiMode txMode)
  {
    m_txop->GotCts (snr, txMode);
  }
  virtual void MissedCts (void)
  {
    m_txop->MissedCts ();
  }
  virtual void GotAck (double snr, EyWifiMode txMode)
  {
    m_txop->GotAck (snr, txMode);
  }
  virtual void MissedAck (void)
  {
    m_txop->MissedAck ();
  }
  virtual void StartNext (void)
  {
    m_txop->StartNext ();
  }
  virtual void Cancel (void)
  {
    m_txop->Cancel ();
  }
  virtual void EndTxNoAck (void)
  {
    m_txop->EndTxNoAck ();
  }

private:
  EyDcaTxop *m_txop;
};

NS_OBJECT_ENSURE_REGISTERED (EyDcaTxop);

TypeId
EyDcaTxop::GetTypeId(void) 
{
  static TypeId tid = TypeId("ns3::EyDcaTxop")
    .SetParent(ns3::EyDcf::GetTypeId())
    .AddConstructor<EyDcaTxop>()
    .AddAttribute("Queue", "The WifiMacQueue object",
                  PointerValue(), MakePointerAccessor(&EyDcaTxop::GetQueue),
                  MakePointerChecker<EyWifiMacQueue>())
    /*.AddTraceSource("BurstTxBegin", "A burst has been received from higher layers and is being processed in preparation "
      "for queueing for transmission.",
      MakeTraceSourceAccessor(&DcaTxop::m_burstTxBeginTrace))
      .AddTraceSource("BurstTxEnd", "Trace source indicating a burst has been completely sent from the channel medium by the device",
      MakeTraceSourceAccessor(&DcaTxop::m_burstTxEndTrace))*/
    .AddTraceSource("BurstTxDrop", "The node detects the prensence of a longer burst. So, it quits the contention.",	
                    MakeTraceSourceAccessor(&EyDcaTxop::m_burstTxDropTrace))
    .AddTraceSource("YieldBegin", "The yield phase has been initiated ",
                    MakeTraceSourceAccessor(&EyDcaTxop::m_yieldBeginTrace))
    .AddTraceSource("YieldDrop", " The yield phase has been interrupted, the node quits the contention",
                    MakeTraceSourceAccessor(&EyDcaTxop::m_yieldDropTrace))
    ;
  return tid;
}

EyDcaTxop::EyDcaTxop() 
  :m_manager(0), 
   m_EyState(0), 
   m_currentPacket(0)
{
  NS_LOG_FUNCTION (this);
  m_transmissionListener = new EyDcaTxop::TransmissionListener(this);
  m_dcf = new EyDcaTxop::Dcf(this);
  m_EyState = new EyState(this);
  m_queue = CreateObject<EyWifiMacQueue>();
  m_rng = new RealRandomStream();
  m_txMiddle = new EyMacTxMiddle();
  m_isBurstSent = false;
  m_yieldStart = Seconds(0);
  m_yTimer = Seconds(0);
  m_burstSlots = 0;
  m_burstListener= new BurstListener(CreateObject<EyYansWifiPhy>()); //Added
  yieldMin=0; 
  yieldMax=9;
}

EyDcaTxop::~EyDcaTxop ()
{
  NS_LOG_FUNCTION (this);
}

void
EyDcaTxop::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  m_queue = 0;
  m_low = 0;
  m_stationManager = 0;
  delete m_transmissionListener;
  delete m_dcf;
  delete m_rng;
  delete m_txMiddle;
  m_transmissionListener = 0;
  m_dcf = 0;
  m_rng = 0;
  m_txMiddle = 0;
}

void
EyDcaTxop::SetManager(EyDcfManager * manager) 
{
  NS_LOG_FUNCTION (this << manager);
  m_manager = manager;
  m_manager->Add(m_EyState);
  m_manager->Add(m_dcf);
}

void
EyDcaTxop::SetLow (Ptr<EyMacLow> low)
{
  NS_LOG_FUNCTION (this << low);
  m_low = low;
}
void
EyDcaTxop::SetWifiRemoteStationManager (Ptr<EyWifiRemoteStationManager> remoteManager)
{
  NS_LOG_FUNCTION (this << remoteManager);
  m_stationManager = remoteManager;
}
void
EyDcaTxop::SetTxOkCallback (TxOk callback)
{
  m_txOkCallback = callback;
}
void
EyDcaTxop::SetTxFailedCallback (TxFailed callback)
{
  m_txFailedCallback = callback;
}

Ptr<EyWifiMacQueue >
EyDcaTxop::GetQueue () const
{
  NS_LOG_FUNCTION (this);
  return m_queue;
}

void
EyDcaTxop::SetMinCw (uint32_t minCw)
{
  NS_LOG_FUNCTION (this << minCw);
  m_dcf->SetCwMin (minCw);
}
void
EyDcaTxop::SetMaxCw (uint32_t maxCw)
{
  NS_LOG_FUNCTION (this << maxCw);
  m_dcf->SetCwMax (maxCw);
}
void
EyDcaTxop::SetAifsn (uint32_t aifsn)
{
  NS_LOG_FUNCTION (this << aifsn);
  m_dcf->SetAifsn (aifsn);
}
uint32_t
EyDcaTxop::GetMinCw (void) const
{
  return m_dcf->GetCwMin ();
}
uint32_t
EyDcaTxop::GetMaxCw (void) const
{
  return m_dcf->GetCwMax ();
}
uint32_t
EyDcaTxop::GetAifsn (void) const
{
  return m_dcf->GetAifsn ();
}

void
EyDcaTxop::Queue (Ptr<const Packet> packet, const EyWifiMacHeader &hdr)
{
  NS_LOG_FUNCTION (this << packet << &hdr);
  EyWifiMacTrailer fcs;
  uint32_t fullPacketSize = hdr.GetSerializedSize () + packet->GetSize () + fcs.GetSerializedSize ();
  m_stationManager->PrepareForQueue (hdr.GetAddr1 (), &hdr,
                                     packet, fullPacketSize);
  m_queue->Enqueue (packet, hdr);
  StartAccessIfNeeded ();
}

int64_t
EyDcaTxop::AssignStreams (int64_t stream)
{
  NS_LOG_FUNCTION (this << stream);
  m_rng->AssignStreams (stream);
  return 1;
}
void
EyDcaTxop::RestartAccessIfNeeded(void)
{
  NS_LOG_FUNCTION (this);
  if ((m_currentPacket != 0 || !m_queue->IsEmpty())
      && !IsDcfAccessRequested())
    {
      DcfRequestAccess();
    }
}
bool
EyDcaTxop::IsDcfAccessRequested(void)
{
  return (m_dcf->IsAccessRequested() || m_EyState->IsAccessRequested());
}
  
void 
EyDcaTxop::DcfRequestAccess(void) 
{
  if ((!m_isBurstSent) & (NeedBurst(m_currentPacket, &m_currentHdr))) 
    {
      NS_LOG_INFO (this << " EyState RequestAccess" << m_EyState << "[mac="
                   << m_low->GetAddress () << "] ");
      m_manager->RequestAccess(m_EyState);
    } 
  else
    {
      NS_LOG_INFO (this << " m_dcf RequestAccess " << m_dcf << "[mac=" <<
                   m_low->GetAddress () << "] ");
      m_manager->RequestAccess(m_dcf);
    }
  
}
void
EyDcaTxop::StartAccessIfNeeded(void) 
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG("m_currentPacket "<<m_currentPacket<<"m_queue->IsEmpty() "<<m_queue->IsEmpty()<<" IsDcfAccessRequested()"<<IsDcfAccessRequested());
  if (m_currentPacket == 0 && !m_queue->IsEmpty()
      && !IsDcfAccessRequested()) 
    {
      DcfRequestAccess();
    }
}

Ptr<EyMacLow>
EyDcaTxop::Low(void) 
{
  return m_low;
}
  
bool
EyDcaTxop::NeedRts (Ptr<const Packet> packet, const EyWifiMacHeader *header)
{
  return m_stationManager->NeedRts (header->GetAddr1 (), header,
                                    packet);
}
bool
EyDcaTxop::NeedBurst(Ptr<const Packet> packet,
		const EyWifiMacHeader * header) 
{
  return m_stationManager->NeedBurst(header->GetAddr1(), header, packet);
}
void
EyDcaTxop::DoStart()
{  
  m_dcf->ResetCw();
  /*uint32_t j=0;
  AcIndex ac = QosUtilsMapTidToAc (m_currentHdr.GetQosTid ());
  switch (ac)
    {
    case AC_VO: j=0;
      break;
    case AC_VI: j=1;
      break;
    case AC_BE: j=2;
      break;
    case AC_BK: j=3;
      break;
    case AC_BE_NQOS: j=4;
      break;
    case AC_UNDEF:
      break;
    }
    m_EyState->StartBackoffNow (j);
    */
    
    m_EyState->StartBackoffNow(m_rng->GetNext(0, 4));
    ns3::EyDcf::DoStart();
}
bool
EyDcaTxop::NeedRtsRetransmission (void)
{
  return m_stationManager->NeedRtsRetransmission (m_currentHdr.GetAddr1 (), &m_currentHdr,
                                                  m_currentPacket);
}

bool
EyDcaTxop::NeedDataRetransmission (void)
{
  return m_stationManager->NeedDataRetransmission (m_currentHdr.GetAddr1 (), &m_currentHdr,
                                                   m_currentPacket);
}
bool
EyDcaTxop::NeedFragmentation (void)
{
  return m_stationManager->NeedFragmentation (m_currentHdr.GetAddr1 (), &m_currentHdr,
                                              m_currentPacket);
}
void
EyDcaTxop::NextFragment (void)
{
  m_fragmentNumber++;
}

uint32_t
EyDcaTxop::GetFragmentSize (void)
{
  return m_stationManager->GetFragmentSize (m_currentHdr.GetAddr1 (), &m_currentHdr,
                                            m_currentPacket, m_fragmentNumber);
}
bool
EyDcaTxop::IsLastFragment (void)
{
  return m_stationManager->IsLastFragment (m_currentHdr.GetAddr1 (), &m_currentHdr,
                                           m_currentPacket, m_fragmentNumber);
}

uint32_t
EyDcaTxop::GetNextFragmentSize (void)
{
  return m_stationManager->GetFragmentSize (m_currentHdr.GetAddr1 (), &m_currentHdr,
                                            m_currentPacket, m_fragmentNumber + 1);
}

uint32_t
EyDcaTxop::GetFragmentOffset (void)
{
  return m_stationManager->GetFragmentOffset (m_currentHdr.GetAddr1 (), &m_currentHdr,
                                              m_currentPacket, m_fragmentNumber);
}

Ptr<Packet>
EyDcaTxop::GetFragmentPacket (EyWifiMacHeader *hdr)
{
  *hdr = m_currentHdr;
  hdr->SetFragmentNumber (m_fragmentNumber);
  uint32_t startOffset = GetFragmentOffset ();
  Ptr<Packet> fragment;
  if (IsLastFragment ())
    {
      hdr->SetNoMoreFragments ();
    }
  else
    {
      hdr->SetMoreFragments ();
    }
  fragment = m_currentPacket->CreateFragment (startOffset,
                                              GetFragmentSize ());
  return fragment;
}

bool
EyDcaTxop::NeedsAccess (void) const
{
  return !m_queue->IsEmpty () || m_currentPacket != 0;
}

void
EyDcaTxop::NotifyBurstAccessGranted(void) 
{
  NS_LOG_FUNCTION (this);
  Low()->SendBurst();
  m_isBurstSent = true;
  NS_LOG_DEBUG ("NotifyBurstAccessGranted " << this << "[mac= " << m_low->
                GetAddress () << "] " << "Burst duration " << Low ()->
                GetBurstDuration ());
  NotifyBurstTxBegin(Low()->GetBurstSlots());
  
  Simulator::Schedule(
                      Low()->GetBurstDuration() + MicroSeconds(7),
                      &EyDcaTxop::StartYieldPhase, this);
}

void
EyDcaTxop::StartYieldPhase(void)
{
  NS_LOG_FUNCTION (this);
  NotifyBurstTxEnd(Low()->GetBurstSlots());
  
  uint32_t yieldSlots = m_rng->GetNext(yieldMin, yieldMax);//m_rng->GetNext(0, 9);
  if (m_manager->IsBusy()) 
    {
      NS_LOG_DEBUG ("Medium is busy");
      NotifyBurstTxDrop(Low()->GetBurstSlots());
      
      m_isBurstSent = false;
      m_burstSlots = Low()->GetBurstSlots();
      Simulator::Schedule(Time(Low()->GetSlotTime() / 1),
                          &EyDcaTxop::CheckBurstEnd, this);
      return;
    }
  m_yieldStart = Simulator::Now();
  m_dcf->StartBackoffNow(yieldSlots);
  NotifyYieldBegin(yieldSlots);
  RestartAccessIfNeeded();
  Simulator::Schedule(Time(Low()->GetBurstDuration() *(yieldSlots+1)),
			&EyDcaTxop::CheckYieldEnd, this);
}

void
EyDcaTxop::CheckBurstEnd() 
{
  NS_LOG_FUNCTION (this);
  if ((m_manager->IsBusy()) & (m_burstSlots < 17)) {
    m_burstSlots += 1;
    Simulator::Schedule(Low()->GetSlotTime(), &EyDcaTxop::CheckBurstEnd,
                        this);
  } else {
    m_burstSlots = 0;
    Simulator::Schedule(Low()->GetSlotTime(), &EyDcaTxop::YieldTimerExpire,
                        this);
  }
}
void
EyDcaTxop::YieldTimerExpire() 
{
  NS_LOG_FUNCTION (this);
  Time slotTime = Low()->GetSlotTime();
  if (m_manager->IsBusy()) 
    {
      Simulator::Schedule(MicroSeconds(90), &EyDcaTxop::RestartAccessIfNeeded, this);
      m_yTimer = Seconds(0);
      m_isBurstSent=false;
      NS_LOG_DEBUG ("Check yield phase end " << m_yTimer);
      return;
    }
  if (m_yTimer > Time(11 * Low()->GetSlotTime())) 
    {
      ExponentialVariable exp(20);
      int rng= exp.GetValue();
      Time expTime = Time(rng * Low()->GetSlotTime());
      NS_LOG_DEBUG ("Hidden node, schedule expTime " << expTime <<
                    " Yield Timer " << m_yTimer);
      m_isBurstSent=false;
      Simulator::Schedule(expTime+MicroSeconds(90), &EyDcaTxop::RestartAccessIfNeeded, this);
      return;
    }
  m_yTimer += slotTime;
  NS_LOG_DEBUG ("Check yield end " << m_yTimer);
  Simulator::Schedule(slotTime, &EyDcaTxop::YieldTimerExpire, this);
}

void
EyDcaTxop::NotifyAccessGranted(void) 
{
  NS_LOG_FUNCTION (this);
  MacLowTransmissionParameters params;
  if (NeedBurst(m_currentPacket, &m_currentHdr))
    {
      params.EnableBurst();
      if ((!m_isBurstSent))
        //|| (Simulator::Now()> Time(m_yieldStart + 12 * Low()->GetSlotTime())))
        {
          NS_LOG_INFO ("NotifyBurstAccessGranted");
          NotifyBurstAccessGranted();
          return;
        }
    }
  if (m_currentPacket == 0) 
    {
      if (m_queue->IsEmpty()) 
        {
          NS_LOG_DEBUG ("queue empty");
          return;
        }
      m_currentPacket = m_queue->Dequeue(&m_currentHdr);
      NS_ASSERT (m_currentPacket != 0);
      uint16_t sequence = m_txMiddle->GetNextSequenceNumberfor(&m_currentHdr);
      m_currentHdr.SetSequenceNumber(sequence);
      m_currentHdr.SetFragmentNumber(0);
      m_currentHdr.SetNoMoreFragments();
      m_currentHdr.SetNoRetry();
      m_fragmentNumber = 0;
      NS_LOG_DEBUG ("dequeued size=" << m_currentPacket->GetSize () <<
                    ", to=" << m_currentHdr.GetAddr1 () <<
                    ", seq=" << m_currentHdr.GetSequenceControl ());
    }
  params.DisableOverrideDurationId();
  if (m_currentHdr.GetAddr1().IsGroup()) 
    {
      params.DisableRts();
      params.DisableAck();
      params.DisableNextData();
      Low()->StartTransmission(m_currentPacket, &m_currentHdr, params,
                               m_transmissionListener);
      
      m_currentPacket = 0;
      m_dcf->ResetCw ();
      m_dcf->StartBackoffNow (m_rng->GetNext (0, m_dcf->GetCw ()));
      StartAccessIfNeeded ();
      NS_LOG_DEBUG ("tx broadcast");
    }
  else
    {
      params.EnableAck ();
      if (NeedFragmentation()) 
        {
          EyWifiMacHeader hdr;
          Ptr<Packet> fragment = GetFragmentPacket(&hdr);
          if (NeedRts(fragment, &hdr)) 
            {
              params.EnableRts();
            }
          else
            {
              params.DisableRts();
            }
          if (IsLastFragment()) 
            {
              NS_LOG_DEBUG ("fragmenting last fragment size=" << fragment->
                            GetSize ());
              params.DisableNextData();
            } 
          else
            {
              NS_LOG_DEBUG ("fragmenting size=" << fragment->GetSize ());
              params.EnableNextData(GetNextFragmentSize());
              }
          Low()->StartTransmission(fragment, &hdr, params,
                                   m_transmissionListener);
        } 
      else
        {
          if (NeedRts(m_currentPacket, &m_currentHdr)) 
            {
              params.EnableRts();
              NS_LOG_DEBUG ("tx unicast rts");
            }
          else
            {
              params.DisableRts();
              NS_LOG_DEBUG ("tx unicast");
            }
          params.DisableNextData();
          Low()->StartTransmission(m_currentPacket, &m_currentHdr, params,
                                   m_transmissionListener);
        }
      }
  m_isBurstSent = false;
  m_yieldStart=Seconds(0);
}
  
void
EyDcaTxop::NotifyInternalCollision (void)
{
  NS_LOG_FUNCTION (this);
  NotifyCollision ();
}
  
void
EyDcaTxop::NotifyCollision(void) 
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("collision");
  m_EyState->StartBackoffNow(m_rng->GetNext(0, 4) + 10);
  Time slotTime = Low()->GetSlotTime();
  uint8_t slots=(m_yTimer.GetSeconds()/slotTime.GetSeconds());
  NotifyYieldDrop(slots);
  RestartAccessIfNeeded();
}
  
void
EyDcaTxop::NotifyChannelSwitching (void)
{
  m_queue->Flush ();
  m_currentPacket = 0;
}
  
void
EyDcaTxop::GotCts (double snr, EyWifiMode txMode)
{
  NS_LOG_FUNCTION (this << snr << txMode);
  NS_LOG_DEBUG ("got cts");
}
void
EyDcaTxop::MissedCts (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("missed cts");
  if (!NeedRtsRetransmission ())
    {
      NS_LOG_DEBUG ("Cts Fail");
      m_stationManager->ReportFinalRtsFailed (m_currentHdr.GetAddr1 (), &m_currentHdr);
      if (!m_txFailedCallback.IsNull ())
        {
          m_txFailedCallback (m_currentHdr);
        }
      // to reset the dcf.
      m_currentPacket = 0;
      m_dcf->ResetCw ();
    }
  else
    {
      m_dcf->UpdateFailedCw ();
    }
  m_dcf->StartBackoffNow (m_rng->GetNext (0, m_dcf->GetCw ()));
  RestartAccessIfNeeded ();
}
void
EyDcaTxop::GotAck (double snr, EyWifiMode txMode)
{
  NS_LOG_FUNCTION (this << snr << txMode);
  if (!NeedFragmentation ()
      || IsLastFragment ())
    {
      NS_LOG_DEBUG ("got ack. tx done.");
      if (!m_txOkCallback.IsNull ())
        {
          m_txOkCallback (m_currentHdr);
        }
      
      /* we are not fragmenting or we are done fragmenting
       * so we can get rid of that packet now.
       */
      m_currentPacket = 0;
      m_dcf->ResetCw ();
      m_dcf->StartBackoffNow (m_rng->GetNext (0, m_dcf->GetCw ()));
      RestartAccessIfNeeded ();
    }
  else
    {
      NS_LOG_DEBUG ("got ack. tx not done, size=" << m_currentPacket->GetSize ());
    }
}
  void
EyDcaTxop::MissedAck (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("missed ack");
  if (!NeedDataRetransmission ())
    {
      NS_LOG_DEBUG ("Ack Fail");
      m_stationManager->ReportFinalDataFailed (m_currentHdr.GetAddr1 (), &m_currentHdr);
      if (!m_txFailedCallback.IsNull ())
        {
          m_txFailedCallback (m_currentHdr);
        }
      // to reset the dcf.
      m_currentPacket = 0;
      m_dcf->ResetCw ();
    }
  else
    {
      NS_LOG_DEBUG ("Retransmit");
      m_currentHdr.SetRetry ();
      m_dcf->UpdateFailedCw ();
    }
  m_dcf->StartBackoffNow (m_rng->GetNext (0, m_dcf->GetCw ()));
  RestartAccessIfNeeded ();
}
void
EyDcaTxop::StartNext (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("start next packet fragment");
  /* this callback is used only for fragments. */
  NextFragment ();
  EyWifiMacHeader hdr;
  Ptr<Packet> fragment = GetFragmentPacket (&hdr);
  MacLowTransmissionParameters params;
  params.EnableAck ();
  params.DisableRts ();
  params.DisableOverrideDurationId ();
  if (IsLastFragment ())
    {
      params.DisableNextData ();
    }
  else
    {
      params.EnableNextData (GetNextFragmentSize ());
    }
  Low ()->StartTransmission (fragment, &hdr, params, m_transmissionListener);
}

void
EyDcaTxop::Cancel (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("transmission cancelled");
  /**
   * This happens in only one case: in an AP, you have two DcaTxop:
   *   - one is used exclusively for beacons and has a high priority.
   *   - the other is used for everything else and has a normal
   *     priority.
   *
   * If the normal queue tries to send a unicast data frame, but
   * if the tx fails (ack timeout), it starts a backoff. If the beacon
   * queue gets a tx oportunity during this backoff, it will trigger
   * a call to this Cancel function.
   *
   * Since we are already doing a backoff, we will get access to
   * the medium when we can, we have nothing to do here. We just
   * ignore the cancel event and wait until we are given again a
   * tx oportunity.
   *
   * Note that this is really non-trivial because each of these
   * frames is assigned a sequence number from the same sequence
   * counter (because this is a non-802.11e device) so, the scheme
   * described here fails to ensure in-order delivery of frames
   * at the receiving side. This, however, does not matter in
   * this case because we assume that the receiving side does not
   * update its <seq,ad> tupple for packets whose destination
   * address is a broadcast address.
   */
}

void 
EyDcaTxop::NotifyBurstTxDrop(uint32_t slots) 
{
  //m_burstTxDropTrace(slots);
  m_burstListener->DoNotifyBurstTxDrop(slots);
}
void 
EyDcaTxop::NotifyBurstTxBegin(uint32_t slots) 
{ 
  //m_burstTxBeginTrace(slots);
  m_burstListener->DoNotifyBurstTxBegin(slots);
}
void
EyDcaTxop::NotifyBurstTxEnd(uint32_t slots) 
{
  //m_burstTxEndTrace(slots);
  m_burstListener->DoNotifyBurstTxEnd(slots);
}

void
EyDcaTxop::SetBurstListener(BurstListener * listener)
{
  m_burstListener=listener;
}
void
EyDcaTxop::EndTxNoAck (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("a transmission that did not require an ACK just finished");
  m_currentPacket = 0;
  m_dcf->ResetCw ();
  m_dcf->StartBackoffNow (m_rng->GetNext (0, m_dcf->GetCw ()));
  StartAccessIfNeeded ();
}
void 
EyDcaTxop::NotifyYieldBegin(uint32_t slots) 
{
  m_yieldBeginTrace(slots);
}
void
EyDcaTxop::NotifyYieldDrop(uint32_t slots) 
{
  m_yieldDropTrace(slots);
}
  void
EyDcaTxop::CheckYieldEnd(void)
{
  if(m_manager->IsBusy()) 
    {
      m_isBurstSent=false;
    }
}
} // namespace ns3
