/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Hana Baccouch <haha.baccouch@inria.fr>
 */
#ifndef BURST_LISTENER_H
#define BURST_LISTENER_H

//#include "ey-dca-txop.h"
#include "ey-wifi-phy.h"
#include "ns3/nstime.h"
#include "ns3/event-id.h"
#include "ey-yans-wifi-phy.h"
namespace ns3 {

/**
 * \ingroup wifi
 * \brief handles burst tracing
 */

class BurstListener
{
public:
  BurstListener (Ptr<EyWifiPhy>  wifiPhy);
  virtual ~BurstListener ();
  /**
   *
   * 
  **/
  void DoNotifyBurstTxEnd(uint32_t slots);
  void DoNotifyBurstTxDrop(uint32_t slots);
  void DoNotifyBurstTxBegin(uint32_t slots);
  void DoNotifyYieldBegin(uint32_t slots);
  void DoNotifyYieldDrop(uint32_t slots);

private:
  TracedCallback<uint32_t> m_burstTxBeginTrace;
  TracedCallback<uint32_t> m_burstTxEndTrace;
  TracedCallback<uint32_t> m_burstTxDropTrace;
  
  TracedCallback<uint32_t> m_yieldBeginTrace;
  TracedCallback<uint32_t> m_yieldDropTrace;
  TracedCallback<uint32_t> m_yieldEndTrace;  
  
  Ptr<EyWifiPhy> m_wifiPhy;
};
}//name space ns3
#endif
