/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */
#ifndef CONSTANT_RATE_WIFI_MANAGER_H
#define CONSTANT_RATE_WIFI_MANAGER_H

#include <stdint.h>

#include "ey-wifi-remote-station-manager.h"

namespace ns3 {

/**
 * \ingroup wifi
 * \brief use constant rates for data and control transmissions
 *
 * This class uses always the same transmission rate for every
 * packet sent.
 */
class EyConstantRateWifiManager : public EyWifiRemoteStationManager
{
public:
  static TypeId GetTypeId (void);
  EyConstantRateWifiManager ();
  virtual ~EyConstantRateWifiManager ();

private:
  // overriden from base class
  virtual EyWifiRemoteStation* DoCreateStation (void) const;
  virtual void DoReportRxOk (EyWifiRemoteStation *station,
                             double rxSnr, EyWifiMode txMode);
  virtual void DoReportRtsFailed (EyWifiRemoteStation *station);
  virtual void DoReportDataFailed (EyWifiRemoteStation *station);
  virtual void DoReportRtsOk (EyWifiRemoteStation *station,
                              double ctsSnr, EyWifiMode ctsMode, double rtsSnr);
  virtual void DoReportDataOk (EyWifiRemoteStation *station,
                               double ackSnr, EyWifiMode ackMode, double dataSnr);
  virtual void DoReportFinalRtsFailed (EyWifiRemoteStation *station);
  virtual void DoReportFinalDataFailed (EyWifiRemoteStation *station);
  virtual EyWifiMode DoGetDataMode (EyWifiRemoteStation *station, uint32_t size);
  virtual EyWifiMode DoGetRtsMode (EyWifiRemoteStation *station);
  virtual bool IsLowLatency (void) const;

  EyWifiMode m_dataMode;
  EyWifiMode m_ctlMode;
};

} // namespace ns3



#endif /* CONSTANT_RATE_WIFI_MANAGER_H */
