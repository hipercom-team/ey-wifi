/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2003,2007 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */
#ifndef ONOE_WIFI_MANAGER_H
#define ONOE_WIFI_MANAGER_H

#include "ey-wifi-remote-station-manager.h"
#include "ns3/nstime.h"

namespace ns3 {

struct EyOnoeWifiRemoteStation;

/**
 * \brief an implementation of the rate control algorithm developed
 *        by Atsushi Onoe
 *
 * \ingroup wifi
 *
 * This algorithm is well known because it has been used as the default
 * rate control algorithm for the madwifi driver. I am not aware of
 * any publication or reference about this algorithm beyond the madwifi
 * source code.
 */
class EyOnoeWifiManager : public EyWifiRemoteStationManager
{
public:
  static TypeId GetTypeId (void);

  EyOnoeWifiManager ();

private:
  // overriden from base class
  virtual EyWifiRemoteStation * DoCreateStation (void) const;
  virtual void DoReportRxOk (EyWifiRemoteStation *station,
                             double rxSnr, EyWifiMode txMode);
  virtual void DoReportRtsFailed (EyWifiRemoteStation *station);
  virtual void DoReportDataFailed (EyWifiRemoteStation *station);
  virtual void DoReportRtsOk (EyWifiRemoteStation *station,
                              double ctsSnr, EyWifiMode ctsMode, double rtsSnr);
  virtual void DoReportDataOk (EyWifiRemoteStation *station,
                               double ackSnr, EyWifiMode ackMode, double dataSnr);
  virtual void DoReportFinalRtsFailed (EyWifiRemoteStation *station);
  virtual void DoReportFinalDataFailed (EyWifiRemoteStation *station);
  virtual EyWifiMode DoGetDataMode (EyWifiRemoteStation *station, uint32_t size);
  virtual EyWifiMode DoGetRtsMode (EyWifiRemoteStation *station);
  virtual bool IsLowLatency (void) const;

  void UpdateRetry (EyOnoeWifiRemoteStation *station);
  void UpdateMode (EyOnoeWifiRemoteStation *station);

  Time m_updatePeriod;
  uint32_t m_addCreditThreshold;
  uint32_t m_raiseThreshold;
};

} // namespace ns3

#endif /* ONOE_WIFI_MANAGER_H */
