/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2004,2005 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */

#include "ey-constant-rate-wifi-manager.h"

#include "ns3/string.h"
#include "ns3/assert.h"


namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED(EyConstantRateWifiManager);

TypeId
EyConstantRateWifiManager::GetTypeId(void) 
{
  static TypeId tid = TypeId("ns3::EyConstantRateWifiManager")
    .SetParent<EyWifiRemoteStationManager> ()
    .AddConstructor<EyConstantRateWifiManager> ()
    .AddAttribute ("DataMode", "The transmission mode to use for every data packet transmission",
                   StringValue("OfdmRate6Mbps"),
                   MakeEyWifiModeAccessor(&EyConstantRateWifiManager::m_dataMode),
                   MakeEyWifiModeChecker())
    .AddAttribute("ControlMode", "The transmission mode to use for every control packet transmission.",
                  StringValue("OfdmRate6Mbps"),
                  MakeEyWifiModeAccessor(&EyConstantRateWifiManager::m_ctlMode),
                  MakeEyWifiModeChecker());
  return tid;
}

EyConstantRateWifiManager::EyConstantRateWifiManager() 
{
}
EyConstantRateWifiManager::~EyConstantRateWifiManager() 
{
}


EyWifiRemoteStation *
EyConstantRateWifiManager::DoCreateStation(void) const 
{
  EyWifiRemoteStation *station = new EyWifiRemoteStation();
  return station;
}


void
EyConstantRateWifiManager::DoReportRxOk(EyWifiRemoteStation * station,
                                      double rxSnr, EyWifiMode txMode)
{
}
void
EyConstantRateWifiManager::DoReportRtsFailed(EyWifiRemoteStation * station) 
{
}
void
EyConstantRateWifiManager::DoReportDataFailed(EyWifiRemoteStation * station) 
{
}
void
EyConstantRateWifiManager::DoReportRtsOk(EyWifiRemoteStation *st,
                                       double ctsSnr, EyWifiMode ctsMode, double rtsSnr)
{
}
void
EyConstantRateWifiManager::DoReportDataOk(EyWifiRemoteStation *st,
                                        double ackSnr, EyWifiMode ackMode, double dataSnr)
{
}
void
EyConstantRateWifiManager::DoReportFinalRtsFailed (EyWifiRemoteStation *station) 
{
}
void
EyConstantRateWifiManager::DoReportFinalDataFailed (EyWifiRemoteStation *station) 
{
}

EyWifiMode
EyConstantRateWifiManager::DoGetDataMode(EyWifiRemoteStation *st,
                                       uint32_t size) 
{
  return m_dataMode;
}
EyWifiMode
EyConstantRateWifiManager::DoGetRtsMode(EyWifiRemoteStation *st) 
{
  return m_ctlMode;
}
bool 
EyConstantRateWifiManager::IsLowLatency(void) const 
{
  return true;
}

} // namespace ns3
