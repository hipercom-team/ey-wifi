/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006,2007 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */
#include "ey-wifi-mode.h"
#include "ns3/simulator.h"
#include "ns3/assert.h"
#include "ns3/log.h"

namespace ns3 {

bool operator == (const EyWifiMode &a, const EyWifiMode &b)
{
  return a.GetUid () == b.GetUid ();
}
std::ostream & operator << (std::ostream & os, const EyWifiMode &mode)
{
  os << mode.GetUniqueName ();
  return os;
}
std::istream & operator >> (std::istream &is, EyWifiMode &mode)
{
  std::string str;
  is >> str;
  mode = EyWifiModeFactory::GetFactory ()->Search (str);
  return is;
}

uint32_t
EyWifiMode::GetBandwidth (void) const
{
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->bandwidth;
}
uint64_t
EyWifiMode::GetPhyRate (void) const
{
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->phyRate;
}
uint64_t
EyWifiMode::GetDataRate (void) const
{
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->dataRate;
}
enum EyWifiCodeRate
EyWifiMode::GetCodeRate (void) const
{
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->codingRate;
}
uint8_t
EyWifiMode::GetConstellationSize (void) const
{
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->constellationSize;
}
std::string
EyWifiMode::GetUniqueName (void) const
{
  // needed for ostream printing of the invalid mode
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->uniqueUid;
}
bool
EyWifiMode::IsMandatory (void) const
{
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->isMandatory;
}
uint32_t
EyWifiMode::GetUid (void) const
{
  return m_uid;
}
enum EyWifiModulationClass
EyWifiMode::GetModulationClass () const
{
  struct EyWifiModeFactory::EyWifiModeItem *item = EyWifiModeFactory::GetFactory ()->Get (m_uid);
  return item->modClass;
}
EyWifiMode::EyWifiMode ()
  : m_uid (0)
{
}
EyWifiMode::EyWifiMode (uint32_t uid)
  : m_uid (uid)
{
}
EyWifiMode::EyWifiMode (std::string name)
{
  *this = EyWifiModeFactory::GetFactory ()->Search (name);
}

ATTRIBUTE_HELPER_CPP (EyWifiMode);

EyWifiModeFactory::EyWifiModeFactory ()
{
}


EyWifiMode
EyWifiModeFactory::CreateWifiMode (std::string uniqueName,
                                 enum EyWifiModulationClass modClass,
                                 bool isMandatory,
                                 uint32_t bandwidth,
                                 uint32_t dataRate,
                                 enum EyWifiCodeRate codingRate,
                                 uint8_t constellationSize)
{
  EyWifiModeFactory *factory = GetFactory ();
  uint32_t uid = factory->AllocateUid (uniqueName);
  EyWifiModeItem *item = factory->Get (uid);
  item->uniqueUid = uniqueName;
  item->modClass = modClass;
  // The modulation class for this EyWifiMode must be valid.
  NS_ASSERT (modClass != WIFI_MOD_CLASS_UNKNOWN);

  item->bandwidth = bandwidth;
  item->dataRate = dataRate;

  item->codingRate = codingRate;

  switch (codingRate)
    {
    case WIFI_CODE_RATE_3_4:
      item->phyRate = dataRate * 4 / 3;
      break;
    case WIFI_CODE_RATE_2_3:
      item->phyRate = dataRate * 3 / 2;
      break;
    case WIFI_CODE_RATE_1_2:
      item->phyRate = dataRate * 2 / 1;
      break;
    case WIFI_CODE_RATE_UNDEFINED:
    default:
      item->phyRate = dataRate;
      break;
    }

  // Check for compatibility between modulation class and coding
  // rate. If modulation class is DSSS then coding rate must be
  // undefined, and vice versa. I could have done this with an
  // assertion, but it seems better to always give the error (i.e.,
  // not only in non-optimised builds) and the cycles that extra test
  // here costs are only suffered at simulation setup.
  if ((codingRate == WIFI_CODE_RATE_UNDEFINED) != (modClass == WIFI_MOD_CLASS_DSSS))
    {
      NS_FATAL_ERROR ("Error in creation of EyWifiMode named " << uniqueName << std::endl
                                                             << "Code rate must be WIFI_CODE_RATE_UNDEFINED iff Modulation Class is WIFI_MOD_CLASS_DSSS");
    }

  item->constellationSize = constellationSize;
  item->isMandatory = isMandatory;

  return EyWifiMode (uid);
}

EyWifiMode
EyWifiModeFactory::Search (std::string name)
{
  EyWifiModeItemList::const_iterator i;
  uint32_t j = 0;
  for (i = m_itemList.begin (); i != m_itemList.end (); i++)
    {
      if (i->uniqueUid == name)
        {
          return EyWifiMode (j);
        }
      j++;
    }

  // If we get here then a matching EyWifiMode was not found above. This
  // is a fatal problem, but we try to be helpful by displaying the
  // list of WifiModes that are supported.
  NS_LOG_UNCOND ("Could not find match for EyWifiMode named \""
                 << name << "\". Valid options are:");
  for (i = m_itemList.begin (); i != m_itemList.end (); i++)
    {
      NS_LOG_UNCOND ("  " << i->uniqueUid);
    }
  // Empty fatal error to die. We've already unconditionally logged
  // the helpful information.
  NS_FATAL_ERROR ("");

  // This next line is unreachable because of the fatal error
  // immediately above, and that is fortunate, because we have no idea
  // what is in EyWifiMode (0), but we do know it is not what our caller
  // has requested by name. It's here only because it's the safest
  // thing that'll give valid code.
  return EyWifiMode (0);
}

uint32_t
EyWifiModeFactory::AllocateUid (std::string uniqueUid)
{
  uint32_t j = 0;
  for (EyWifiModeItemList::const_iterator i = m_itemList.begin ();
       i != m_itemList.end (); i++)
    {
      if (i->uniqueUid == uniqueUid)
        {
          return j;
        }
      j++;
    }
  uint32_t uid = m_itemList.size ();
  m_itemList.push_back (EyWifiModeItem ());
  return uid;
}

struct EyWifiModeFactory::EyWifiModeItem *
EyWifiModeFactory::Get (uint32_t uid)
{
  NS_ASSERT (uid < m_itemList.size ());
  return &m_itemList[uid];
}

EyWifiModeFactory *
EyWifiModeFactory::GetFactory (void)
{
  static bool isFirstTime = true;
  static EyWifiModeFactory factory;
  if (isFirstTime)
    {
      uint32_t uid = factory.AllocateUid ("Invalid-EyWifiMode");
      EyWifiModeItem *item = factory.Get (uid);
      item->uniqueUid = "Invalid-EyWifiMode";
      item->bandwidth = 0;
      item->dataRate = 0;
      item->phyRate = 0;
      item->modClass = WIFI_MOD_CLASS_UNKNOWN;
      item->constellationSize = 0;
      item->codingRate = WIFI_CODE_RATE_UNDEFINED;
      item->isMandatory = false;
      isFirstTime = false;
    }
  return &factory;
}

} // namespace ns3
