/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2005,2006 INRIA
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Mathieu Lacage <mathieu.lacage@sophia.inria.fr>
 */
#include "ey-wifi-phy-state-helper.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/trace-source-accessor.h"

NS_LOG_COMPONENT_DEFINE ("EyWifiPhyStateHelper");

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (EyWifiPhyStateHelper);

TypeId
EyWifiPhyStateHelper::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EyWifiPhyStateHelper")
    .SetParent<Object> ()
    .AddConstructor<EyWifiPhyStateHelper> ()
    .AddTraceSource ("State",
                     "The state of the PHY layer",
                     MakeTraceSourceAccessor (&EyWifiPhyStateHelper::m_stateLogger))
    .AddTraceSource ("RxOk",
                     "A packet has been received successfully.",
                     MakeTraceSourceAccessor (&EyWifiPhyStateHelper::m_rxOkTrace))
    .AddTraceSource ("RxError",
                     "A packet has been received unsuccessfully.",
                     MakeTraceSourceAccessor (&EyWifiPhyStateHelper::m_rxErrorTrace))
    .AddTraceSource ("Tx", "Packet transmission is starting.",
                     MakeTraceSourceAccessor (&EyWifiPhyStateHelper::m_txTrace))
  ;
  return tid;
}

EyWifiPhyStateHelper::EyWifiPhyStateHelper ()
  : m_rxing (false),
    m_endTx (Seconds (0)),
    m_endRx (Seconds (0)),
    m_endCcaBusy (Seconds (0)),
    m_endSwitching (Seconds (0)),
    m_startTx (Seconds (0)),
    m_startRx (Seconds (0)),
    m_startCcaBusy (Seconds (0)),
    m_startSwitching (Seconds (0)),
    m_previousStateChangeTime (Seconds (0))
{
  NS_LOG_FUNCTION (this);
}

void
EyWifiPhyStateHelper::SetReceiveOkCallback (EyWifiPhy::RxOkCallback callback)
{
  m_rxOkCallback = callback;
}
void
EyWifiPhyStateHelper::SetReceiveErrorCallback (EyWifiPhy::RxErrorCallback callback)
{
  m_rxErrorCallback = callback;
}
void
EyWifiPhyStateHelper::RegisterListener (EyWifiPhyListener *listener)
{
  m_listeners.push_back (listener);
}

bool
EyWifiPhyStateHelper::IsStateIdle (void)
{
  return (GetState () == EyWifiPhy::IDLE);
}
bool
EyWifiPhyStateHelper::IsStateBusy (void)
{
  return (GetState () != EyWifiPhy::IDLE);
}
bool
EyWifiPhyStateHelper::IsStateCcaBusy (void)
{
  return (GetState () == EyWifiPhy::CCA_BUSY);
}
bool
EyWifiPhyStateHelper::IsStateRx (void)
{
  return (GetState () == EyWifiPhy::RX);
}
bool
EyWifiPhyStateHelper::IsStateTx (void)
{
  return (GetState () == EyWifiPhy::TX);
}
bool
EyWifiPhyStateHelper::IsStateSwitching (void)
{
  return (GetState () == EyWifiPhy::SWITCHING);
}



Time
EyWifiPhyStateHelper::GetStateDuration (void)
{
  return Simulator::Now () - m_previousStateChangeTime;
}

Time
EyWifiPhyStateHelper::GetDelayUntilIdle (void)
{
  Time retval;

  switch (GetState ())
    {
    case EyWifiPhy::RX:
      retval = m_endRx - Simulator::Now ();
      break;
    case EyWifiPhy::TX:
      retval = m_endTx - Simulator::Now ();
      break;
    case EyWifiPhy::CCA_BUSY:
      retval = m_endCcaBusy - Simulator::Now ();
      break;
    case EyWifiPhy::SWITCHING:
      retval = m_endSwitching - Simulator::Now ();
      break;
    case EyWifiPhy::IDLE:
      retval = Seconds (0);
      break;
    default:
      NS_FATAL_ERROR ("Invalid WifiPhy state.");
      retval = Seconds (0);
      break;
    }
  retval = Max (retval, Seconds (0));
  return retval;
}

Time
EyWifiPhyStateHelper::GetLastRxStartTime (void) const
{
  return m_startRx;
}

enum EyWifiPhy::State
EyWifiPhyStateHelper::GetState (void)
{
  if (m_endTx > Simulator::Now ())
    {
      return EyWifiPhy::TX;
    }
  else if (m_rxing)
    {
      return EyWifiPhy::RX;
    }
  else if (m_endSwitching > Simulator::Now ())
    {
      return EyWifiPhy::SWITCHING;
    }
  else if (m_endCcaBusy > Simulator::Now ())
    {
      return EyWifiPhy::CCA_BUSY;
    }
  else
    {
      return EyWifiPhy::IDLE;
    }
}


void
EyWifiPhyStateHelper::NotifyTxStart (Time duration)
{
  for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyTxStart (duration);
    }
}
void
EyWifiPhyStateHelper::NotifyRxStart (Time duration)
{
  for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyRxStart (duration);
    }
}
void
EyWifiPhyStateHelper::NotifyRxEndOk (void)
{
  for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyRxEndOk ();
    }
}
void
EyWifiPhyStateHelper::NotifyRxEndError (void)
{
  for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyRxEndError ();
    }
}
void
EyWifiPhyStateHelper::NotifyMaybeCcaBusyStart (Time duration)
{
  for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyMaybeCcaBusyStart (duration);
    }
}
void
EyWifiPhyStateHelper::NotifySwitchingStart (Time duration)
{
  for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifySwitchingStart (duration);
    }
}

void
EyWifiPhyStateHelper::LogPreviousIdleAndCcaBusyStates (void)
{
  Time now = Simulator::Now ();
  Time idleStart = Max (m_endCcaBusy, m_endRx);
  idleStart = Max (idleStart, m_endTx);
  idleStart = Max (idleStart, m_endSwitching);
  NS_ASSERT (idleStart <= now);
  if (m_endCcaBusy > m_endRx
      && m_endCcaBusy > m_endSwitching
      && m_endCcaBusy > m_endTx)
    {
      Time ccaBusyStart = Max (m_endTx, m_endRx);
      ccaBusyStart = Max (ccaBusyStart, m_startCcaBusy);
      ccaBusyStart = Max (ccaBusyStart, m_endSwitching);
      m_stateLogger (ccaBusyStart, idleStart - ccaBusyStart, EyWifiPhy::CCA_BUSY);
    }
  m_stateLogger (idleStart, now - idleStart, EyWifiPhy::IDLE);
}

void
EyWifiPhyStateHelper::SwitchToTx (Time txDuration, Ptr<const Packet> packet, EyWifiMode txMode,
                                EyWifiPreamble preamble, uint8_t txPower)
{
  m_txTrace (packet, txMode, preamble, txPower);
  NotifyTxStart (txDuration);
  Time now = Simulator::Now ();
  switch (GetState ())
    {
    case EyWifiPhy::RX:
      /* The packet which is being received as well
       * as its endRx event are cancelled by the caller.
       */
      m_rxing = false;
      m_stateLogger (m_startRx, now - m_startRx, EyWifiPhy::RX);
      m_endRx = now;
      break;
    case EyWifiPhy::CCA_BUSY:
      {
        Time ccaStart = Max (m_endRx, m_endTx);
        ccaStart = Max (ccaStart, m_startCcaBusy);
        ccaStart = Max (ccaStart, m_endSwitching);
        m_stateLogger (ccaStart, now - ccaStart, EyWifiPhy::CCA_BUSY);
      } break;
    case EyWifiPhy::IDLE:
      LogPreviousIdleAndCcaBusyStates ();
      break;
    case EyWifiPhy::SWITCHING:
    default:
      NS_FATAL_ERROR ("Invalid WifiPhy state.");
      break;
    }
  m_stateLogger (now, txDuration, EyWifiPhy::TX);
  m_previousStateChangeTime = now;
  m_endTx = now + txDuration;
  m_startTx = now;
}
void
EyWifiPhyStateHelper::SwitchToRx (Time rxDuration)
{
  NS_ASSERT (IsStateIdle () || IsStateCcaBusy ());
  NS_ASSERT (!m_rxing);
  NotifyRxStart (rxDuration);
  Time now = Simulator::Now ();
  switch (GetState ())
    {
    case EyWifiPhy::IDLE:
      LogPreviousIdleAndCcaBusyStates ();
      break;
    case EyWifiPhy::CCA_BUSY:
      {
        Time ccaStart = Max (m_endRx, m_endTx);
        ccaStart = Max (ccaStart, m_startCcaBusy);
        ccaStart = Max (ccaStart, m_endSwitching);
        m_stateLogger (ccaStart, now - ccaStart, EyWifiPhy::CCA_BUSY);
      } break;
    case EyWifiPhy::SWITCHING:
    case EyWifiPhy::RX:
    case EyWifiPhy::TX:
      NS_FATAL_ERROR ("Invalid WifiPhy state.");
      break;
    }
  m_previousStateChangeTime = now;
  m_rxing = true;
  m_startRx = now;
  m_endRx = now + rxDuration;
  NS_ASSERT (IsStateRx ());
}

void
EyWifiPhyStateHelper::SwitchToChannelSwitching (Time switchingDuration)
{
  NotifySwitchingStart (switchingDuration);
  Time now = Simulator::Now ();
  switch (GetState ())
    {
    case EyWifiPhy::RX:
      /* The packet which is being received as well
       * as its endRx event are cancelled by the caller.
       */
      m_rxing = false;
      m_stateLogger (m_startRx, now - m_startRx, EyWifiPhy::RX);
      m_endRx = now;
      break;
    case EyWifiPhy::CCA_BUSY:
      {
        Time ccaStart = Max (m_endRx, m_endTx);
        ccaStart = Max (ccaStart, m_startCcaBusy);
        ccaStart = Max (ccaStart, m_endSwitching);
        m_stateLogger (ccaStart, now - ccaStart, EyWifiPhy::CCA_BUSY);
      } break;
    case EyWifiPhy::IDLE:
      LogPreviousIdleAndCcaBusyStates ();
      break;
    case EyWifiPhy::TX:
    case EyWifiPhy::SWITCHING:
    default:
      NS_FATAL_ERROR ("Invalid WifiPhy state.");
      break;
    }

  if (now < m_endCcaBusy)
    {
      m_endCcaBusy = now;
    }

  m_stateLogger (now, switchingDuration, EyWifiPhy::SWITCHING);
  m_previousStateChangeTime = now;
  m_startSwitching = now;
  m_endSwitching = now + switchingDuration;
  NS_ASSERT (IsStateSwitching ());
}

void
EyWifiPhyStateHelper::SwitchFromRxEndOk (Ptr<Packet> packet, double snr, EyWifiMode mode, enum EyWifiPreamble preamble)
{
  m_rxOkTrace (packet, snr, mode, preamble);
  NotifyRxEndOk ();
  DoSwitchFromRx ();
  if (!m_rxOkCallback.IsNull ())
    {
      m_rxOkCallback (packet, snr, mode, preamble);
    }

}
void
EyWifiPhyStateHelper::SwitchFromRxEndError (Ptr<const Packet> packet, double snr)
{
  m_rxErrorTrace (packet, snr);
  NotifyRxEndError ();
  DoSwitchFromRx ();
  if (!m_rxErrorCallback.IsNull ())
    {
      m_rxErrorCallback (packet, snr);
    }
}

void
EyWifiPhyStateHelper::DoSwitchFromRx (void)
{
  NS_ASSERT (IsStateRx ());
  NS_ASSERT (m_rxing);

  Time now = Simulator::Now ();
  m_stateLogger (m_startRx, now - m_startRx, EyWifiPhy::RX);
  m_previousStateChangeTime = now;
  m_rxing = false;

  NS_ASSERT (IsStateIdle () || IsStateCcaBusy ());
}
void
EyWifiPhyStateHelper::SwitchMaybeToCcaBusy (Time duration)
{
  NotifyMaybeCcaBusyStart (duration);
  Time now = Simulator::Now ();
  switch (GetState ())
    {
    case EyWifiPhy::SWITCHING:
      break;
    case EyWifiPhy::IDLE:
      LogPreviousIdleAndCcaBusyStates ();
      break;
    case EyWifiPhy::CCA_BUSY:
      break;
    case EyWifiPhy::RX:
      break;
    case EyWifiPhy::TX:
      break;
    }
  m_startCcaBusy = now;
  m_endCcaBusy = std::max (m_endCcaBusy, now + duration);
}

} // namespace ns3
